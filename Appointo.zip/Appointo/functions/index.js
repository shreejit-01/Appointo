const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();
const fcm = admin.messaging();

// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
exports.ratingProvider = functions.firestore
    .document('reviews/{docId}')
    .onCreate(async (snap, context) => {
        const review = snap.data();
        var rating = parseFloat(review.rating);
        const vendorUid = review.uid;
        var vendorRef = db.collection('vendors').doc(vendorUid);
        const val = await vendorRef.get();
        const vendor = val.data();
        var totalReviews = vendor.totalReviews === undefined ? 0 : vendor.totalReviews;
        var avgRatings = vendor.rating === undefined ? 0 : vendor.rating;
        var totalRatings = totalReviews * avgRatings;
        var newTotalReviews = totalReviews + 1;
        var newAvgRatings = (totalRatings + rating) / newTotalReviews;
        return vendorRef.update({
            'rating': newAvgRatings.toFixed(2),
            'totalReviews': newTotalReviews,
        });
    });
exports.notifications = functions.firestore
    .document('bookings/{docId}')
    .onUpdate(async (change, context) => {
        const data = change.after.data();
        const status = data.status;
        const token = data.notificationToken;
        var userDoc = await db.collection('users').doc(data.byUID).get();
        var userData = userDoc.data();
        var notificationsEnabled = userData.notificationEnabled;
        if ((status === 'booked' || status === 'rejected') && notificationsEnabled === 'true') {
            const payload = {
                notification: {
                    title: `Order ${status}`,
                    body: `Your order with ${data.bookedVendor} has been ${status}`,
                    click_action: 'FLUTTER_NOTIFICATION_CLICK', 
                    sound: "default"
                }
            };
            return fcm.sendToDevice(token, payload);
        }
        else
            return 0;
    });