import 'dart:async';

import 'package:enterprise/pages/googleSignUpLanding.dart';
import 'package:enterprise/pages/help.dart';
import 'package:enterprise/pages/home.dart';
import 'package:enterprise/pages/login.dart';
import 'package:enterprise/pages/ordersPage.dart';
import 'package:enterprise/pages/profileEditPage.dart';
import 'package:enterprise/pages/profilePage.dart';
import 'package:enterprise/pages/search.dart';
import 'package:enterprise/pages/settingsPage.dart';
import 'package:enterprise/pages/signup.dart';
import 'package:enterprise/pages/spalshScreen.dart';
import 'package:enterprise/services/analytics.dart';
import 'package:enterprise/services/themeNotifier.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fluttertoast/fluttertoast.dart';

void main() {
  runApp(ChangeNotifierProvider<ThemeNotifier>(
      create: (BuildContext context) {
        return ThemeNotifier();
      },
      child: MyApp()));
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeNotifier>(builder: (context, value, child) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Shell Enterprice',
        themeMode: value.themeMode,
        theme: ThemeData(
            primaryColor: Colors.white,
            brightness: Brightness.light,
            accentColor: Colors.black,
            cardColor: Colors.white,
            canvasColor: Colors.grey,
            backgroundColor: Colors.white,
            bottomAppBarColor: Colors.white,
            scaffoldBackgroundColor: Colors.white,
            dialogBackgroundColor: Colors.white,
            cursorColor: Colors.black,
            buttonColor: formColor,
            secondaryHeaderColor: Colors.white,
            splashColor: Colors.white,
            unselectedWidgetColor: Colors.white,
            textSelectionColor: Colors.blue,
            textSelectionHandleColor: Colors.blue,
            bottomNavigationBarTheme: BottomNavigationBarThemeData(
                backgroundColor: Colors.white.withOpacity(0.8)),
            textTheme: TextTheme(
              bodyText1:
                  TextStyle(fontSize: 22, color: Colors.black), //Profile Name
              bodyText2: GoogleFonts.cousine(fontSize: 15), //EditProfile
              headline1: GoogleFonts.workSans(
                  fontWeight: FontWeight.bold,
                  fontSize: 11,
                  color: Colors.black), //Category card Text
              headline2: TextStyle(color: Colors.black),
              headline3: TextStyle(color: Colors.black),
              headline4: TextStyle(color: Colors.black),
              headline5: TextStyle(color: Colors.black),
              headline6: TextStyle(color: Colors.black),
              subtitle1: TextStyle(color: Colors.black),
              subtitle2: TextStyle(color: Colors.black),
            )),
        darkTheme: ThemeData(
            primaryColor: Colors.black,
            brightness: Brightness.dark,
            cursorColor: Colors.white,
            accentColor: Colors.white,
            errorColor: Colors.white,
            cardColor: Colors.black87.withOpacity(.75),
            canvasColor: Colors.white.withOpacity(0.8),
            backgroundColor: Colors.black,
            bottomAppBarColor: Colors.black,
            scaffoldBackgroundColor: Colors.black,
            dialogBackgroundColor: Colors.black,
            buttonColor: formColor,
            secondaryHeaderColor: Colors.black,
            splashColor: Colors.black,
            unselectedWidgetColor: Colors.black,
            textSelectionColor: Colors.blue,
            textSelectionHandleColor: Colors.blue,
            bottomNavigationBarTheme: BottomNavigationBarThemeData(
                backgroundColor: Colors.white.withOpacity(0.2)),
            textTheme: TextTheme(
              bodyText1: TextStyle(fontSize: 22, color: Colors.white),
              bodyText2: GoogleFonts.cousine(fontSize: 15, color: Colors.white),
              headline1: GoogleFonts.workSans(
                  fontWeight: FontWeight.bold,
                  fontSize: 11,
                  color: Colors.white), //Category card Text
              headline2: TextStyle(color: Colors.white),
              headline3: TextStyle(color: Colors.white),
              headline4: TextStyle(color: Colors.white),
              headline5: TextStyle(color: Colors.white),
              headline6: TextStyle(color: Colors.white),
              subtitle1: TextStyle(color: Colors.white),
              subtitle2: TextStyle(color: Colors.white),
            )),
        initialRoute: '/',
        navigatorObservers: [Analytics().getAnalyticsObserver()],
        routes: {
          '/': (context) => SplashScreen(),
          'login': (context) => LoginPage(),
          'signup': (context) => SignUpPage(),
          'home': (context) => Home(),
          'gsignin': (context) => GoogleSignUpLandingPage(),
          'searchPage': (context) => SearchPage(
                filterCategory: [],
              ),
          'Profile': (context) => ProfilePage(),
          // 'Your Order Status': (context) => GoogleSignUpLandingPage(),
          'history': (context) => Orders(
                history: true,
              ), //HistoryPage(),
          'orders': (context) => Orders(
                history: false,
              ),
          'Setting': (context) => SettingsPage(),
          'EditProfilePage': (context) => EditProfilePage(),
          'Help': (context) => HelpPage(),
        },
      );
    });
  }
}
