import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';

class Analytics {
  final FirebaseAnalytics analytics = FirebaseAnalytics();
  FirebaseAnalyticsObserver getAnalyticsObserver() =>
      FirebaseAnalyticsObserver(analytics: analytics);
  setUserId(String id) async {
    await analytics.setUserId(id);
  }

  signUpType(String type) async {
    await analytics.logSignUp(signUpMethod: type);
  }

  logVendorView(
      {String vendorId, String vendorName, String vendorCategory}) async {
    await analytics.logViewItem(
        itemId: vendorId, itemName: vendorName, itemCategory: vendorCategory);
  }

  logBookingEvent(
      {String vendorId,
      String vendorName,
      String vendorCategory,
      List services,
      bool self}) async {
    var date = DateTime.now();
    await analytics.logEvent(name: 'booking_event', parameters: {
      'vendor': vendorName,
      'category': vendorCategory,
      'servicesSelected': services.toString(),
      'timeOfBooking': date.toString(),
      'bookedForSelf': self,
    });
  }

  logSearchEvent({String searchTerm}) async {
    await analytics.logSearch(
      searchTerm: searchTerm,
    );
  }

  logCurrentScreen({String name}) async {
    await analytics.setCurrentScreen(
        screenName: name, screenClassOverride: name);
  }
}
