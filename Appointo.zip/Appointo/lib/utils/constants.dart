import 'package:enterprise/pages/dashboard.dart';
import 'package:enterprise/pages/ordersPage.dart';
import 'package:enterprise/pages/profilePage.dart';
import 'package:enterprise/pages/search.dart';
import 'package:enterprise/pages/settingsPage.dart';
import 'package:enterprise/services/analytics.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';

var ins = Firestore.instance;

Color formColor = Color(0xFF3498DB); // login/signup form
Color blue = Color(0xFF0B23F9); //blue
Color cyan = Color(0xFF00F5FF); //Cyan
Color white = Color(0xFFFFFFFF); //White
Color pink = Color(0xFFFF0080); //Pink

//settingsPage varibales
bool notification = true;
bool darkTheme = false;
String version = '';

//User varibales
TextEditingController emailController = TextEditingController();
TextEditingController passwordController = TextEditingController();
TextEditingController nameController = TextEditingController();
TextEditingController phoneNumberController = TextEditingController();
TextEditingController confirmPasswordController = TextEditingController();
TextEditingController addressController = TextEditingController();
String photoURL;
String uid;

//Positions
Position position;

//Maps Api Key
String mapsApiKey = 'AIzaSyCE4fBDRjRhFmjyv2w-zn7c-ng4jj12E1g';

//Dashboard

//Category Slider
List<dynamic> categoryList = [], categoryIconList = [];

//Image Slider
List imageList;

//popularList
List popularList;

//nearbyList
List nearbyList;

//bottomNav
List<Widget> navigateTo = [
  DashBoard(),
  Orders(
    history: false,
  ),
  SearchPage(
    filterCategory: [],
  ),
  SettingsPage(),
  ProfilePage(),
];
double size = 35;
int bottomNavIndex = 0;

List<Function> navAction = [
  (context) {
    bottomNavIndex = 0;

    // Analytics().logCurrentScreen(name: 'landingPage');
    Navigator.pushNamedAndRemoveUntil(context, 'home', (route) => false);
  },
  (context) {
    bottomNavIndex = 1;
    // Analytics().logCurrentScreen(name: 'ordersPage');
    Navigator.pushNamedAndRemoveUntil(context, 'home', (route) => false);
  },
  (context) {
    Analytics().logCurrentScreen(name: 'searchPage');
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => SearchPage(
            filterCategory: [],
          ),
        ));
  },
  (context) {
    bottomNavIndex = 3;
    // Analytics().logCurrentScreen(name: 'settingsPage');
    Navigator.pushNamedAndRemoveUntil(context, 'home', (route) => false);
  },
  (context) {
    bottomNavIndex = 4;
    // Analytics().logCurrentScreen(name: 'profilePgae');
    Navigator.pushNamedAndRemoveUntil(context, 'home', (route) => false);
  },
];
List<BottomNavigationBarItem> items = [
  BottomNavigationBarItem(
    icon: Container(height: size, child: Image.asset('assets/home.png')),
    title: Text('Home'),
  ),
  BottomNavigationBarItem(
    icon: Container(height: size, child: Image.asset('assets/order.png')),
    title: Text('Orders'),
  ),
  BottomNavigationBarItem(
    icon: Container(height: size, child: Image.asset('assets/search.png')),
    title: Text('Search'),
  ),
  BottomNavigationBarItem(
    icon: Container(
      height: size,
      child: Icon(
        Icons.settings,
        color: Colors.blue.withOpacity(.9),
        size: size,
      ),
    ),
    title: Text('Settings'),
  ),
  BottomNavigationBarItem(
    icon: Container(
      height: size,
      width: size,
      child: CircleAvatar(
          backgroundImage: photoURL == null ? null : NetworkImage(photoURL),
          child: photoURL == null
              ? Text(
                  nameController.text.length == 0
                      ? 'P'
                      : nameController.text[0],
                  style: TextStyle(fontSize: 30, color: pink),
                )
              : null),
    ),
    title: Text('Profile'),
  ),
];

//exit app?
bool exit = false;
