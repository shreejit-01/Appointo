import 'package:enterprise/services/analytics.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter/material.dart';

class SignUpPage extends StatefulWidget {
  SignUpPage({Key key}) : super(key: key);

  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final _formKey = GlobalKey<FormState>();

  //Email validating regex
  static String p =
      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
  RegExp regExp = new RegExp(p);
  bool _obscure = true,
      _isSignUpWithEmailLoading = false,
      _isLogningWithGoogleLoading = false;
  FocusNode name = FocusNode(),
      email = FocusNode(),
      phone = FocusNode(),
      password = FocusNode(),
      confirmPassword = FocusNode();
  @override
  void initState() {
    emailController.clear();
    passwordController.clear();
    nameController.clear();
    phoneNumberController.clear();
    confirmPasswordController.clear();
    addressController.clear();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: formColor,
      body: SingleChildScrollView(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Container(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.03,
                        ),
                        Container(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                  alignment: Alignment.center,
                                  child: Text(
                                    "Sign Up",
                                    style:
                                        TextStyle(fontSize: 20, color: white),
                                  )),
                              SizedBox(
                                height: 20,
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width * 0.85,
                                child: signupForm(),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                                child: _isSignUpWithEmailLoading
                                    ? Container(
                                        child: CircularProgressIndicator(),
                                      )
                                    : Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.85,
                                        child: MaterialButton(
                                          // borderSide: BorderSide(color: white),
                                          color: white,
                                          splashColor: white.withOpacity(0.5),
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(20)),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 10.0),
                                            child: Text("SIGNUP",
                                                style: TextStyle(
                                                    color: formColor,
                                                    fontSize: 18)),
                                          ),
                                          onPressed: () {
                                            setState(() {
                                              _isSignUpWithEmailLoading = true;
                                            });
                                            if (_formKey.currentState
                                                .validate()) {
                                              signup(
                                                  email: emailController.text,
                                                  password:
                                                      passwordController.text);
                                            } else {
                                              setState(() {
                                                _isSignUpWithEmailLoading =
                                                    false;
                                              });
                                            }
                                          },
                                        ),
                                      ),
                              ),
                              SizedBox(
                                height: 8,
                              ),
                              Text(
                                "- OR -",
                                style: TextStyle(color: white),
                              ),
                              SizedBox(
                                height: 8,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 10),
                                    child: Text(
                                      "Sign up with",
                                      style: TextStyle(color: white),
                                    ),
                                  ),
                                  Padding(
                                    padding:
                                        const EdgeInsets.symmetric(vertical: 0),
                                    child: Container(
                                      child: _isLogningWithGoogleLoading
                                          ? Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: CircularProgressIndicator(
                                                valueColor:
                                                    AlwaysStoppedAnimation<
                                                        Color>(white),
                                              ),
                                            )
                                          : MaterialButton(
                                              color: white,
                                              shape: CircleBorder(),
                                              onPressed: () {
                                                setState(() {
                                                  _isLogningWithGoogleLoading =
                                                      true;
                                                });
                                                signinWithGoogle();
                                              },
                                              child: Container(
                                                height: 55,
                                                width: 55,
                                                padding: EdgeInsets.all(12),
                                                child: Image(
                                                  image: AssetImage(
                                                    "assets/google_logo.png",
                                                  ),
                                                  fit: BoxFit.fill,
                                                ),
                                              ),
                                            ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.02,
                        ),
                      ],
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: GestureDetector(
                        onTap: () => Navigator.pushNamed(context, 'login'),
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 15),
                          child: RichText(
                            text: TextSpan(
                                style: TextStyle(color: white.withOpacity(0.5)),
                                children: [
                                  TextSpan(text: "Have an Account? "),
                                  TextSpan(
                                      text: 'Sign in',
                                      style: TextStyle(color: white))
                                ]),
                          ),
                        ),
                      ),
                    ),
                  ]),
            ),
          ),
        ),
      ),
    );
  }

  signupForm() {
    return Container(
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Container(
              height: 94,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8, left: 1),
                    child: Text(
                      "Name",
                      style: TextStyle(color: white, fontSize: 14),
                    ),
                  ),
                  TextFormField(
                    controller: nameController,
                    focusNode: name,
                    style: TextStyle(height: 1.4, color: white),
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      hintStyle: TextStyle(color: white.withOpacity(0.5)),
                      hintText: "Enter Your Name",
                      focusColor: white,
                      prefixIcon: Icon(
                        Icons.account_circle,
                        color: white,
                      ),
                      contentPadding: EdgeInsets.only(left: 10),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: white)),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(
                              width: 1, color: white.withOpacity(0.5))),
                      focusedErrorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                      errorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                    ),
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Name must not be empty';
                      } else
                        return null;
                    },
                    onFieldSubmitted: (value) {
                      email.requestFocus();
                    },
                  ),
                ],
              ),
            ),
            Container(
              height: 94,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8, left: 1),
                    child: Text(
                      "Email",
                      style: TextStyle(color: white, fontSize: 14),
                    ),
                  ),
                  TextFormField(
                    controller: emailController,
                    focusNode: email,
                    textInputAction: TextInputAction.next,
                    style: TextStyle(height: 1.4, color: white),
                    decoration: InputDecoration(
                      hintStyle: TextStyle(color: white.withOpacity(0.5)),
                      hintText: "Enter Your Email",
                      focusColor: white,
                      prefixIcon: Icon(
                        Icons.email,
                        color: white,
                      ),
                      contentPadding: EdgeInsets.only(left: 10),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: white)),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(
                              width: 1, color: white.withOpacity(0.5))),
                      focusedErrorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                      errorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                    ),
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'email must not be empty';
                      } else if (!regExp.hasMatch(value)) {
                        return 'Check your email';
                      } else
                        return null;
                    },
                    onFieldSubmitted: (value) {
                      phone.requestFocus();
                    },
                  ),
                ],
              ),
            ),
            Container(
              height: 94,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8, left: 1),
                    child: Text(
                      "Phone No",
                      style: TextStyle(color: white, fontSize: 14),
                    ),
                  ),
                  TextFormField(
                    controller: phoneNumberController,
                    focusNode: phone,
                    keyboardType: TextInputType.numberWithOptions(),
                    textInputAction: TextInputAction.next,
                    style: TextStyle(height: 1.4, color: white),
                    decoration: InputDecoration(
                      hintStyle: TextStyle(color: white.withOpacity(0.5)),
                      hintText: "Enter Your Phone no",
                      focusColor: white,
                      prefixIcon: Icon(
                        Icons.phone,
                        color: white,
                      ),
                      contentPadding: EdgeInsets.only(left: 10),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: white)),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(
                              width: 1, color: white.withOpacity(0.5))),
                      focusedErrorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                      errorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                    ),
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'phone number must not be empty';
                      } else
                        return null;
                    },
                    onFieldSubmitted: (value) {
                      password.requestFocus();
                    },
                  ),
                ],
              ),
            ),
            Container(
              height: 94,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8, left: 1),
                    child: Text(
                      "Password",
                      style: TextStyle(color: white, fontSize: 14),
                    ),
                  ),
                  TextFormField(
                    controller: passwordController,
                    focusNode: password,
                    // obscuringCharacter: '•',
                    keyboardType: TextInputType.emailAddress,
                    style: TextStyle(height: 1.4, color: white),
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      hintStyle: TextStyle(color: white.withOpacity(0.5)),
                      hintText: "Enter Your Password",
                      focusColor: white,
                      prefixIcon: Icon(
                        Icons.lock,
                        color: white,
                      ),
                      contentPadding: EdgeInsets.only(left: 10),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: white)),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(
                              width: 1, color: white.withOpacity(0.5))),
                      focusedErrorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                      errorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                    ),
                    obscureText: _obscure,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'password must not be empty';
                      } else if (value.length <= 6) {
                        return 'password is too short';
                      } else
                        return null;
                    },
                    onFieldSubmitted: (value) {
                      confirmPassword.requestFocus();
                    },
                  ),
                ],
              ),
            ),
            Container(
              height: 94,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8, left: 1),
                    child: Text(
                      "Confirm Password",
                      style: TextStyle(color: white, fontSize: 14),
                    ),
                  ),
                  TextFormField(
                    controller: confirmPasswordController,
                    focusNode: confirmPassword,
                    obscureText: true,
                    keyboardType: TextInputType.emailAddress,
                    style: TextStyle(height: 1.4, color: white),
                    decoration: InputDecoration(
                      hintStyle: TextStyle(color: white.withOpacity(0.5)),
                      hintText: "Confirm Password",
                      focusColor: white,
                      prefixIcon: Icon(
                        Icons.lock,
                        color: white,
                      ),
                      contentPadding: EdgeInsets.only(left: 10),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: white)),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(
                              width: 1, color: white.withOpacity(0.5))),
                      focusedErrorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                      errorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                    ),
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'confirm password must not be empty';
                      } else if (value != passwordController.text) {
                        return 'passwords does not match';
                      } else
                        return null;
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  signup({String email, String password}) async {
    AuthResult auth;
    await FirebaseAuth.instance
        .createUserWithEmailAndPassword(email: email, password: password)
        .then((value) {
      auth = value;
    }).catchError((e) {
      Fluttertoast.showToast(msg: e.message);
      setState(() {
        _isSignUpWithEmailLoading = false;
      });
      return;
    });

    uid = auth.user.uid;
    await ins.collection('users').document(auth.user.uid).setData({
      'name': nameController.text,
      'email': emailController.text,
      'phone': phoneNumberController.text,
      'photoURL': null,
      'notificationEnabled': 'true'
    });
    setState(() {
      _isSignUpWithEmailLoading = false;
    });
    Analytics().signUpType('email');
    Fluttertoast.showToast(msg: "Sign up Success");
    Navigator.pushNamedAndRemoveUntil(context, 'home', (route) => false);
  }

  signinWithGoogle() async {
    GoogleSignIn _googleSignIn = GoogleSignIn();
    GoogleSignInAccount googleUser = await _googleSignIn.signIn();
    if (googleUser != null) {
      bool exisitngEmail = await exisitngUser(googleUser.email);
      GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      AuthCredential credential = GoogleAuthProvider.getCredential(
          accessToken: googleAuth.accessToken, idToken: googleAuth.idToken);
      if (exisitngEmail) {
        setState(() {
          _isLogningWithGoogleLoading = false;
        });
        Fluttertoast.showToast(msg: "Existing user, Sign in to continue");
      } else {
        await FirebaseAuth.instance
            .signInWithCredential(credential)
            .then((value) async {
          print(value.user);
          nameController.text = value.user.displayName;
          emailController.text = value.user.email;
          phoneNumberController.text = value.user.phoneNumber;
          photoURL = value.user.photoUrl;
          uid = value.user.uid;
        }).catchError((e) {
          setState(() {
            _isLogningWithGoogleLoading = false;
          });
          Fluttertoast.showToast(msg: e.toString());
        });
        setState(() {
          _isLogningWithGoogleLoading = false;
        });
        Analytics().signUpType('google');
        Navigator.pushNamed(context, 'gsignin');
      }
    } else {
      setState(() {
        _isLogningWithGoogleLoading = false;
      });
    }
  }

  Future<bool> exisitngUser(String email) async {
    QuerySnapshot snap = await ins
        .collection('users')
        .where('email', isEqualTo: email)
        .getDocuments();
    if (snap.documents.length != 0)
      return true;
    else
      return false;
  }
}
