import 'package:enterprise/utils/constants.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_sign_in/google_sign_in.dart';

class ProfilePage extends StatefulWidget {
  ProfilePage({Key key}) : super(key: key);

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    Map<String, Function> options = {
      'Edit Profile': (context) {
        Navigator.pushNamed(context, 'EditProfilePage');
      },
      'History': (context) {
        Navigator.pushNamed(context, 'history');
      },
      'Help': (context) {
        Navigator.pushNamed(context, 'Help');
      },
      'Log out': (context) {
        emailController.clear();
        passwordController.clear();
        nameController.clear();
        phoneNumberController.clear();
        confirmPasswordController.clear();
        GoogleSignIn _googleSignIn = GoogleSignIn();
        _googleSignIn.signOut();
        FirebaseAuth.instance.signOut();
        Fluttertoast.showToast(msg: "you have been loged out");
        Navigator.pushNamedAndRemoveUntil(context, 'login', (route) => false);
      },
    };
    List<String> iconPath = [
      'assets/edit.png',
      'assets/history.png',
      'assets/help.png',
      'assets/logout.png'
    ];
    return Scaffold(
      // bottomNavigationBar: BottomNavigationBar(
      //   backgroundColor: Theme.of(context).cardColor,
      //   items: items,
      //   type: BottomNavigationBarType.fixed,
      //   currentIndex: bottomNavIndex,
      //   selectedItemColor: formColor,
      //   unselectedItemColor: Colors.grey,
      //   onTap: (value) {
      //     setState(() {
      //       bottomNavIndex = value;
      //     });
      //     navAction[value](context);
      //   },
      // ),
      body: SafeArea(
        child: Stack(alignment: Alignment.bottomCenter, children: [
          Container(
            height: MediaQuery.of(context).size.height,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 40,
                  ),
                  Hero(
                    tag: 'tag1',
                    child: CircleAvatar(
                        maxRadius: MediaQuery.of(context).size.width / 4,
                        backgroundImage:
                            photoURL == null ? null : NetworkImage(photoURL),
                        backgroundColor: white,
                        child: photoURL == null
                            ? Text(
                                nameController.text == null
                                    ? 'P'
                                    : nameController.text[0],
                                style: TextStyle(fontSize: 100, color: pink),
                              )
                            : null),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 15.0),
                    child: Text(
                      nameController.text,
                      style: Theme.of(context).textTheme.bodyText1,
                    ),
                  ),
                  Divider(
                    indent: 50,
                    endIndent: 50,
                    thickness: 1,
                    color: Theme.of(context).accentColor,
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.8,
                    child: Container(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 20, horizontal: 20),
                        child: Column(
                          children: List.generate(
                              options.length,
                              (index) => Padding(
                                    padding: const EdgeInsets.only(bottom: 20),
                                    child: GestureDetector(
                                      onTap: () {
                                        print(options.values.toList());
                                        options[options.keys.elementAt(index)](
                                            context);
                                      },
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Container(
                                            height: 50,
                                            child: Image.asset(iconPath[index]),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsets.only(left: 10),
                                            child: Text(
                                              options.keys.elementAt(index),
                                              style: GoogleFonts.workSans(
                                                  fontSize: 20),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  )),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Text('v' + version,
              style: GoogleFonts.vesperLibre(color: Colors.grey, fontSize: 18)),
        ]),
      ),
    );
  }
}
