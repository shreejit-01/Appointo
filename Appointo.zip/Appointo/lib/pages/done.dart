import 'package:enterprise/pages/home.dart';
import 'package:enterprise/pages/ordersPage.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:jiffy/jiffy.dart';

class DonePage extends StatefulWidget {
  final Map data;
  DonePage({Key key, this.data}) : super(key: key);

  @override
  _DonePageState createState() => _DonePageState();
}

class _DonePageState extends State<DonePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              child: Image.asset('assets/thumbsup.png'),
            ),
            Text("Done!",
                style: GoogleFonts.workSans(
                    fontSize: 50,
                    color: Theme.of(context).accentColor.withOpacity(.8),
                    fontWeight: FontWeight.w500)),
            Container(
              width: MediaQuery.of(context).size.width * .8,
              child: Divider(
                thickness: 1,
                color: Colors.grey,
              ),
            ),
            Container(
                width: MediaQuery.of(context).size.width * .8,
                child: RichText(
                    text: TextSpan(
                        children: [
                      TextSpan(text: "Your service for "),
                      TextSpan(
                          text:
                              Jiffy(widget.data['date']).format('do MMMM yyyy'),
                          style: GoogleFonts.workSans(
                              fontSize: 20,
                              color: Theme.of(context).accentColor,
                              fontWeight: FontWeight.w600)),
                      TextSpan(text: " has been booked at time "),
                      TextSpan(
                          text:
                              "${widget.data['time']}, ${Jiffy(widget.data['date']).EEEE}. ",
                          style: GoogleFonts.workSans(
                              fontSize: 20,
                              color: Theme.of(context).accentColor,
                              fontWeight: FontWeight.w600)),
                      TextSpan(
                        text:
                            "\nPlease check the status in the order window below.",
                      )
                    ],
                        style: GoogleFonts.workSans(
                            fontSize: 18,
                            color: Colors.grey,
                            fontWeight: FontWeight.w500)))),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  RaisedButton(
                      onPressed: () {
                        bottomNavIndex = 1;
                        Navigator.pushNamedAndRemoveUntil(
                            context, 'home', (route) => false);
                      },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5)),
                      color: Colors.red.withOpacity(.9),
                      padding:
                          EdgeInsets.symmetric(horizontal: 25, vertical: 8),
                      child: Text("Continue",
                          style: GoogleFonts.workSans(
                              fontSize: 30, color: Colors.white)))
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
