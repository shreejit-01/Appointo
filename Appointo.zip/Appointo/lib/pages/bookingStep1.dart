import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:enterprise/pages/bookingStep2.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fluttertoast/fluttertoast.dart';

class BookingStep1 extends StatefulWidget {
  final DocumentSnapshot snap;
  BookingStep1({Key key, this.snap}) : super(key: key);

  @override
  _BookingStep1State createState() => _BookingStep1State();
}

class _BookingStep1State extends State<BookingStep1> {
  List selectedServiceIndex = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Expanded(
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  Center(
                    child: Container(
                      height: MediaQuery.of(context).size.height * .4,
                      width: MediaQuery.of(context).size.width * .8,
                      child: Image.asset(
                        'assets/step.png',
                        fit: BoxFit.fitWidth,
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: Icon(
                          Icons.arrow_back_ios,
                          color: Colors.blue,
                        ),
                        iconSize: 30,
                        padding: EdgeInsets.all(10),
                        onPressed: () => Navigator.pop(context),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 10),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: List.generate(3, (index) {
                            return Container(
                              width: 20.0,
                              height: 20.0,
                              margin: EdgeInsets.symmetric(
                                  vertical: 15.0, horizontal: 8.0),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                    color: Theme.of(context).accentColor),
                                color: 0 == index
                                    ? Theme.of(context).accentColor
                                    : Theme.of(context).primaryColor,
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Text("Step 1 : select the services",
                        style: GoogleFonts.workSans(fontSize: 20)),
                    SizedBox(
                      height: 20,
                    ),
                    serviceList(),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text("${selectedServiceIndex.length} services selected",
                      style: GoogleFonts.workSans(
                          fontSize: 17, color: Colors.grey)),
                  RaisedButton(
                      onPressed: () {
                        if (selectedServiceIndex.length == 0) {
                          Fluttertoast.showToast(
                              msg: "select atleast one service");
                        } else
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => BookingStep2(
                                    snap: widget.snap,
                                    selectedServices: selectedServiceIndex),
                              ));
                      },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5)),
                      color: Colors.red.withOpacity(.9),
                      padding:
                          EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                      child: Text("Next",
                          style: GoogleFonts.workSans(
                              fontSize: 30, color: Colors.white)))
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  serviceList() {
    List typesofServicesList = widget.snap['services'];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          SizedBox(
            width: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: List.generate(
                typesofServicesList.length,
                (index) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            if (selectedServiceIndex.contains(index))
                              selectedServiceIndex.remove(index);
                            else
                              selectedServiceIndex.add(index);
                          });
                        },
                        child: Stack(
                          alignment: Alignment.topRight,
                          children: [
                            Container(
                              width: 109,
                              height: 220,
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Container(
                                        height: 130,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(8),
                                            border: Border.all(
                                              color: selectedServiceIndex
                                                      .contains(index)
                                                  ? Colors.blue
                                                  : Colors.transparent,
                                              width: selectedServiceIndex
                                                      .contains(index)
                                                  ? 4
                                                  : 1,
                                            )),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(4),
                                          child: Image.network(
                                            typesofServicesList[index]
                                                ['photoUrl'],
                                            fit: BoxFit.fill,
                                          ),
                                        )),
                                  ),
                                  Text(
                                      typesofServicesList[index]['serviceName'],
                                      textAlign: TextAlign.center,
                                      style: GoogleFonts.workSans(
                                        fontWeight: FontWeight.w500,
                                      )),
                                  Text(typesofServicesList[index]['price'],
                                      textAlign: TextAlign.center,
                                      style: GoogleFonts.workSans(
                                          color: Colors.grey)),
                                ],
                              ),
                            ),
                            Visibility(
                              visible: selectedServiceIndex.contains(index),
                              child: Container(
                                width: 20,
                                height: 20,
                                decoration: BoxDecoration(
                                    color: Colors.cyan,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.cyan)),
                              ),
                            )
                          ],
                        ),
                      ),
                    )),
          ),
        ],
      ),
    );
  }
}
