import 'package:enterprise/services/themeNotifier.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SettingsPage extends StatefulWidget {
  SettingsPage({Key key}) : super(key: key);

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          child: Stack(alignment: Alignment.bottomCenter, children: [
            Container(
              height: MediaQuery.of(context).size.height,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                      decoration: new BoxDecoration(
                        image: new DecorationImage(
                          image: new AssetImage('assets/settings_bg.png'),
                          fit: BoxFit.cover,
                        ),
                      ),
                      height: MediaQuery.of(context).size.height * 0.4,
                      width: MediaQuery.of(context).size.width,
                      padding: EdgeInsets.all(
                          MediaQuery.of(context).size.height * 0.4 / 4),
                      child: Hero(
                        tag: 'tag1',
                        child: CircleAvatar(
                          maxRadius: 40,
                          backgroundColor: Colors.blue,
                          child: Text(
                            "A",
                            style: GoogleFonts.averiaSerifLibre(fontSize: 100),
                          ),
                          // backgroundImage: AssetImage('assets/brandLogo.png'),
                        ),
                      ),
                    ),
                    Container(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 35, vertical: 20),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  child: Image.asset('assets/notification.png'),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.6,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Notification",
                                        style:
                                            GoogleFonts.workSans(fontSize: 20),
                                      ),
                                      Container(
                                        width: 60,
                                        child: Switch(
                                          value: notification,
                                          materialTapTargetSize:
                                              MaterialTapTargetSize.shrinkWrap,
                                          onChanged: (value) {
                                            setState(() {
                                              notification = value;
                                            });
                                            ins
                                                .collection('users')
                                                .document(uid)
                                                .updateData({
                                              'notificationEnabled':
                                                  value.toString()
                                            });
                                          },
                                          activeColor: Colors.red,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 30,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  child: Image.asset('assets/sun.png'),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.6,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Dark mode",
                                        style:
                                            GoogleFonts.workSans(fontSize: 20),
                                      ),
                                      Container(
                                        width: 60,
                                        child: Switch(
                                          value: Theme.of(context).brightness ==
                                              Brightness.dark, //darkTheme,
                                          materialTapTargetSize:
                                              MaterialTapTargetSize.shrinkWrap,
                                          onChanged: (value) {
                                            setState(() {
                                              darkTheme = value;
                                            });
                                            Provider.of<ThemeNotifier>(context,
                                                    listen: false)
                                                .updateTheme(value);
                                          },
                                          activeColor: Colors.red,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Text('v' + version,
                style:
                    GoogleFonts.vesperLibre(color: Colors.grey, fontSize: 18)),
          ]),
        ),
      ),
    );
  }
}
