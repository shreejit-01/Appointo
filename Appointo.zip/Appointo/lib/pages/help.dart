import 'package:flutter/material.dart';

class HelpPage extends StatelessWidget {
  const HelpPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Help"),
      ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Contact Us",
                  style: TextStyle(
                      fontSize: MediaQuery.of(context).size.width / 8)),
              SizedBox(height: 20),
              // Image.asset("assets/brandLogo.png"),
              CircleAvatar(
                radius: MediaQuery.of(context).size.width / 4,
                backgroundColor: Colors.blue,
                child: Text(
                  "SE",
                  style: TextStyle(
                      fontSize: MediaQuery.of(context).size.width / 4,
                      color: Colors.white),
                ),
              ),
              SizedBox(height: 20),
              Row(
                children: [
                  IconButton(icon: Icon(Icons.mail), onPressed: () {}),
                  Text("shellindiaa11456@gmail.com")
                ],
              ),
              Row(
                children: [
                  IconButton(icon: Icon(Icons.phone), onPressed: () {}),
                  Text("+91 70284 80098")
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
