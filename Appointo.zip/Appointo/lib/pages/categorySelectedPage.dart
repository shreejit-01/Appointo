import 'package:enterprise/pages/bookingStep3.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:table_calendar/table_calendar.dart';

class ServiceDetails extends StatefulWidget {
  final DocumentSnapshot snap;
  final String service;
  ServiceDetails({Key key, this.snap, this.service}) : super(key: key);

  @override
  _ServiceDetailsState createState() => _ServiceDetailsState();
}

class _ServiceDetailsState extends State<ServiceDetails> {
  GlobalKey<ScaffoldState> _scafKey = GlobalKey<ScaffoldState>();
  CarouselController _carouselController = CarouselController();
  CalendarController _calendarController = CalendarController();
  PageStorageKey<dynamic> _pageStorageKey;
  int _current = 0;
  List<String> _imageList = [
    'https://bizongo.com/blog/wp-content/uploads/2019/04/COSMETIC-PACKAGING_1-1024x421.jpg',
    'https://i.pinimg.com/236x/3d/65/7c/3d657cc0b9931f60f043ad6b024b538a.jpg',
    'https://resources.news.e.abb.com/images/2019/2/8/1/food-safe-bearings-cover-image.jpg',
    'https://lirp-cdn.multiscreensite.com/a4654f05/dms3rep/multi/opt/lead-screws-768x423-560w.jpg'
  ];

  List workingDays, availableTime;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scafKey,
      body: SafeArea(
          child: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      IconButton(
                          visualDensity: VisualDensity(horizontal: 2),
                          icon: Icon(
                            Icons.menu,
                            size: 30,
                            color: white,
                          ),
                          onPressed: () {
                            _scafKey.currentState.openDrawer();
                          })
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: imageSlider(),
                  )
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                decoration: BoxDecoration(
                    color: white,
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(23))),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                          color: white,
                          borderRadius:
                              BorderRadius.vertical(top: Radius.circular(23))),
                      child: Padding(
                        padding:
                            const EdgeInsets.only(right: 20, top: 10, left: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  widget.snap['category'].toString(),
                                  style: TextStyle(fontSize: 15),
                                )
                              ],
                            ),
                            Text(
                              widget.service,
                              style: TextStyle(fontSize: 20, height: 0.5),
                            )
                          ],
                        ),
                      ),
                    ),
                    Divider(
                      thickness: 1,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 10),
                      child: Container(
                        decoration: BoxDecoration(
                            color: white,
                            borderRadius: BorderRadius.circular(5),
                            boxShadow: [
                              BoxShadow(blurRadius: 5, color: Colors.grey)
                            ]),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    "Description",
                                    style: TextStyle(fontSize: 16),
                                  ),
                                ],
                              ),
                              Text("-------------description---------------"),
                              Text("-------------description---------------"),
                              Text("-------------description---------------"),
                              Text("-------------description---------------"),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Divider(
                      thickness: 1,
                    ),
                    daysOfWeek(),
                    Divider(
                      thickness: 1,
                    ),
                    timeOfWorking(),
                    Divider(
                      thickness: 1,
                    ),
                    availableDates(),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        RaisedButton(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                          color: blue,
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => BookingStep3(
                                    snap: widget.snap,
                                  ),
                                ));
                          },
                          child: Container(
                            width: MediaQuery.of(context).size.width * 0.6,
                            height: 45,
                            alignment: Alignment.center,
                            child: Text(
                              "Book",
                              style: TextStyle(color: white, fontSize: 18),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      )),
    );
  }

  Widget daysOfWeek() {
    workingDays = widget.snap['availableDaysofWeek'];
    List<String> weekDays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 20, top: 10, bottom: 10),
            child: Text(
              "Days of week",
              // style: TextStyle(color: Colors.grey),
            ),
          ),
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                  weekDays.length,
                  (index) => Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          width: MediaQuery.of(context).size.width * 0.6 / 7,
                          height: MediaQuery.of(context).size.width * 0.6 / 7,
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                              color: workingDays.contains(index)
                                  ? white
                                  : Colors.red[400]),
                          alignment: Alignment.center,
                          child: Text(
                            weekDays[index],
                            style: TextStyle(fontSize: 18),
                          ),
                        ),
                      )),
            ),
          )
        ],
      ),
    );
  }

  Widget timeOfWorking() {
    availableTime = widget.snap['availableTimeofDay'].toString().split(', ');
    return Container(
      padding: EdgeInsets.only(right: 30),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                    left: 20, top: 10, bottom: 10, right: 10),
                child: Text(
                  "Time of working",
                  // style: TextStyle(color: Colors.grey),
                ),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.07,
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.4,
                padding: EdgeInsets.symmetric(vertical: 5),
                decoration: BoxDecoration(
                    color: white, boxShadow: [BoxShadow(color: Colors.grey)]),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: List.generate(
                      availableTime.length,
                      (index) => Padding(
                            padding: const EdgeInsets.only(bottom: 5.0),
                            child: Container(
                              child: Text(
                                availableTime[index],
                                style: TextStyle(fontSize: 18),
                              ),
                            ),
                          )),
                ),
              )
            ],
          ),
        ],
      ),
    );
  }

  Widget availableDates() {
    List<int> workingDays = [1, 2, 3, 4, 5, 6, 7];
    List availabledays = widget.snap['availableDaysofWeek'];
    availabledays.forEach((element) {
      workingDays.remove(int.parse(element.toString()));
    });
    availableTime = widget.snap['availableTimeofDay'].toString().split(', ');
    return Container(
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                    left: 20, top: 10, bottom: 10, right: 10),
                child: Text(
                  "Available Dates",
                  // style: TextStyle(color: Colors.grey),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 20,
          ),
          Container(
            width: MediaQuery.of(context).size.width * .8,
            // height: 300,
            decoration: BoxDecoration(
                color: white, boxShadow: [BoxShadow(color: Colors.grey)]),
            child: TableCalendar(
              calendarController: _calendarController,
              availableGestures: AvailableGestures.horizontalSwipe,
              formatAnimation: FormatAnimation.slide,
              weekendDays: workingDays,
              enabledDayPredicate: (day) =>
                  (day.compareTo(DateTime.now()) < 0 ? false : true),
              initialCalendarFormat: CalendarFormat.month,
              availableCalendarFormats: const {CalendarFormat.month: ''},
              onDaySelected: (day, events) {},
              calendarStyle:
                  CalendarStyle(markersColor: blue, selectedColor: blue),
              startDay: DateTime.now(),
            ),
          ),
        ],
      ),
    );
  }

  Widget imageSlider() {
    return Container(
      child: Column(
        children: [
          CarouselSlider(
            options: CarouselOptions(
              carouselController: _carouselController,
              height: 150,
              initialPage: 0,
              pageViewKey: _pageStorageKey,
              onPageChanged: (index, reason) {
                setState(() {
                  _current = index;
                });
              },
            ),
            items: List.generate(
                _imageList.length,
                (index) => Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        decoration: BoxDecoration(
                            // borderRadius: BorderRadius.circular(10),
                            color: white,
                            boxShadow: [
                              BoxShadow(color: Colors.grey, blurRadius: 3)
                            ]),
                        width: MediaQuery.of(context).size.width * 0.8,
                        child: Image.network(
                          _imageList[index],
                          fit: BoxFit.fill,
                        ),
                      ),
                    )),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: _imageList.map((url) {
              int index = _imageList.indexOf(url);
              return Container(
                width: 8.0,
                height: 8.0,
                margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 4.0),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: _current == index ? white : Colors.grey),
                  color: _current == index ? white : Colors.grey,
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
