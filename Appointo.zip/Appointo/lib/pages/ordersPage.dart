import 'package:enterprise/services/pushNotification.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:enterprise/widgets.dart/orderStatusCard.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

//Same page is used for Orders and History
// history == false -> Orders Page
// history == true -> History Page
class Orders extends StatefulWidget {
  final bool history;
  Orders({Key key, this.history}) : super(key: key);

  @override
  _OrdersState createState() => _OrdersState();
}

class _OrdersState extends State<Orders> {
  List orderList;
  @override
  void initState() {
    PushNotificationsManager().init();
    widget.history ? getHistory() : getOrders();
    super.initState();
  }

  getHistory() async {
    String curTime = DateTime.now()
        .subtract(Duration(hours: 4))
        .toString(); //Querry with buffer time of 4 hours
    QuerySnapshot query = await ins
        .collection('bookings')
        .where('byUID', isEqualTo: uid)
        .orderBy('date', descending: false)
        .where('date', isLessThan: curTime)
        .getDocuments();
    setState(() {
      orderList = query.documents;
    });
  }

  getOrders() async {
    String curTime = DateTime.now()
        .subtract(Duration(hours: 4))
        .toString(); //Querry with buffer time of 4 hours
    QuerySnapshot query = await ins
        .collection('bookings')
        .where('byUID', isEqualTo: uid)
        .orderBy('date', descending: false)
        .where('date', isGreaterThanOrEqualTo: curTime)
        .getDocuments();
    setState(() {
      orderList = query.documents;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: widget.history
          ? AppBar(
              title: Text("History of Orders"),
            )
          : null,
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 20,
                ),
                widget.history
                    ? Container()
                    : Align(
                        alignment: Alignment.center,
                        child: Container(
                          width: MediaQuery.of(context).size.width * .8,
                          child: Image.asset(
                            'assets/calendar.png',
                            fit: BoxFit.fitWidth,
                          ),
                        ),
                      ),
                orderList == null
                    ? CircularProgressIndicator()
                    : orderList.length == 0
                        ? Padding(
                            padding: const EdgeInsets.symmetric(vertical: 30),
                            child: Text(
                              "Nothing to show",
                              style: Theme.of(context).textTheme.bodyText1,
                            ),
                          )
                        : orderStatus()
              ],
            ),
          ),
        ),
      ),
    );
  }

  orderStatus() {
    return Column(
      children: List.generate(
          orderList.length,
          (index) => OrderStatusCard(
                snap: orderList[index],
                history: widget.history,
                popup: false,
              )),
    );
  }
}
