import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:fluttertoast/fluttertoast.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  FocusNode email = FocusNode();
  FocusNode password = FocusNode();

  //email validation regex
  static String p =
      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
  RegExp regExp = new RegExp(p);

  bool _obscureText = true;
  bool _loginLoading = false;
  bool _isLogningWithGoogleLoading = false;
  Color _iconColor = white.withOpacity(0.5);
  @override
  void initState() {
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    emailController.clear();
    passwordController.clear();
    nameController.clear();
    phoneNumberController.clear();
    confirmPasswordController.clear();
    addressController.clear();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomPadding: false,
      backgroundColor: formColor,
      body: SafeArea(
        child: Center(
          child: Container(
            // height: 600,
            child: Stack(children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.95,
                width: MediaQuery.of(context).size.width,
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: GestureDetector(
                    onTap: () => Navigator.pushNamed(context, 'signup'),
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 15),
                      child: RichText(
                        text: TextSpan(
                            style: TextStyle(color: white.withOpacity(0.5)),
                            children: [
                              TextSpan(text: "Don't have an Account? "),
                              TextSpan(
                                  text: 'Sign up',
                                  style: TextStyle(color: white))
                            ]),
                      ),
                    ),
                  ),
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Container(
                          // height: 500,
                          decoration: BoxDecoration(
                              color: formColor,
                              borderRadius: BorderRadius.circular(10)),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                    alignment: Alignment.center,
                                    child: Text(
                                      "Sign In",
                                      style:
                                          TextStyle(fontSize: 20, color: white),
                                    )),
                                SizedBox(
                                  height: 30,
                                ),
                                Container(
                                    width: MediaQuery.of(context).size.width *
                                        0.75,
                                    child: loginForm()),
                                SizedBox(
                                  height: 25,
                                ),
                                _loginLoading
                                    ? Padding(
                                        padding: const EdgeInsets.all(7.0),
                                        child: CircularProgressIndicator(),
                                      )
                                    : Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.75,
                                        child: MaterialButton(
                                          // borderSide: BorderSide(color: formColor),
                                          color: white.withOpacity(0.98),
                                          splashColor:
                                              formColor.withOpacity(0.5),
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(20)),
                                          onPressed: () {
                                            setState(() {
                                              _loginLoading = true;
                                            });
                                            if (_formKey.currentState
                                                .validate()) {
                                              signinWithEmail(
                                                  email: emailController.text,
                                                  password:
                                                      passwordController.text,
                                                  context: context);
                                            } else
                                              setState(() {
                                                _loginLoading = false;
                                              });
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 10.0),
                                            child: Text(
                                              'LOGIN',
                                              style: TextStyle(
                                                  color: formColor,
                                                  fontSize: 18),
                                            ),
                                          ),
                                        ),
                                      ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "- OR -",
                        style: TextStyle(color: white),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            child: Text(
                              "Sign in with",
                              style: TextStyle(color: white),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 2),
                            child: Container(
                              child: _isLogningWithGoogleLoading
                                  ? Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                                white),
                                      ),
                                    )
                                  : MaterialButton(
                                      color: white,
                                      shape: CircleBorder(),
                                      onPressed: () {
                                        setState(() {
                                          _isLogningWithGoogleLoading = true;
                                        });
                                        signinWithGoogle();
                                      },
                                      child: Container(
                                        height: 55,
                                        width: 55,
                                        padding: EdgeInsets.all(12),
                                        child: Image(
                                          image: AssetImage(
                                            "assets/google_logo.png",
                                          ),
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                    ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget loginForm() {
    return Form(
      key: _formKey,
      child: Container(
        height: 230,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Container(
              height: 94,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8, left: 1),
                    child: Text(
                      "Email",
                      style: TextStyle(color: white, fontSize: 14),
                    ),
                  ),
                  TextFormField(
                    textInputAction: TextInputAction.next,
                    focusNode: email,
                    controller: emailController,
                    style: TextStyle(height: 1.4, color: white),
                    decoration: InputDecoration(
                        fillColor: white,
                        labelStyle: TextStyle(color: white),
                        hintText: "Enter Your Email",
                        hintStyle: TextStyle(color: white.withOpacity(0.5)),
                        prefixIcon: Icon(
                          Icons.email,
                          color: white,
                        ),
                        focusColor: white,
                        contentPadding: EdgeInsets.only(left: 10),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5),
                            borderSide: BorderSide(width: 1, color: white)),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5),
                            borderSide: BorderSide(
                                width: 1, color: white.withOpacity(0.7))),
                        focusedErrorBorder: OutlineInputBorder(
                            gapPadding: 0,
                            borderRadius: BorderRadius.circular(5),
                            borderSide:
                                BorderSide(width: 1, color: Colors.red)),
                        errorBorder: OutlineInputBorder(
                            gapPadding: 0,
                            borderRadius: BorderRadius.circular(5),
                            borderSide:
                                BorderSide(width: 1, color: Colors.red))),
                    keyboardType: TextInputType.emailAddress,
                    autocorrect: true,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Enter your email';
                      } else if (!regExp.hasMatch(value)) {
                        return 'Check your email';
                      } else
                        return null;
                    },
                    onFieldSubmitted: (value) {
                      password.requestFocus();
                    },
                  ),
                ],
              ),
            ),
            Spacer(),
            Container(
              height: 118,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8, left: 1),
                    child: Text(
                      "Password",
                      style: TextStyle(color: white, fontSize: 14),
                    ),
                  ),
                  TextFormField(
                    focusNode: password,
                    textInputAction: TextInputAction.done,
                    controller: passwordController,
                    obscureText: _obscureText,
                    style: TextStyle(height: 1.4, color: white),
                    decoration: InputDecoration(
                        fillColor: white,
                        labelStyle: TextStyle(color: white),
                        hintText: "Enter Your Password",
                        hintStyle: TextStyle(color: white.withOpacity(0.5)),
                        prefixIcon: Icon(
                          Icons.lock,
                          color: white,
                        ),
                        suffixIcon: IconButton(
                            icon: Icon(Icons.remove_red_eye),
                            color: _iconColor,
                            onPressed: () {
                              setState(() {
                                _obscureText = !_obscureText;
                              });
                              if (_obscureText)
                                setState(() {
                                  _iconColor = white.withOpacity(0.5);
                                });
                              else
                                setState(() {
                                  _iconColor = white;
                                });
                            }),
                        focusColor: white,
                        contentPadding: EdgeInsets.only(left: 10),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5),
                            borderSide: BorderSide(width: 1, color: white)),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5),
                            borderSide: BorderSide(
                                width: 1, color: white.withOpacity(0.7))),
                        focusedErrorBorder: OutlineInputBorder(
                            gapPadding: 0,
                            borderRadius: BorderRadius.circular(5),
                            borderSide:
                                BorderSide(width: 1, color: Colors.red)),
                        errorBorder: OutlineInputBorder(
                            gapPadding: 0,
                            borderRadius: BorderRadius.circular(5),
                            borderSide:
                                BorderSide(width: 1, color: Colors.red))),
                    keyboardType: TextInputType.emailAddress,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Enter your password';
                      } else
                        return null;
                    },
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        GestureDetector(
                          child: Text(
                            "Forgot Password?",
                            style: TextStyle(color: white.withOpacity(0.97)),
                          ),
                          onTap: () {
                            if (emailController.text.isEmpty ||
                                !regExp.hasMatch(emailController.text)) {
                              Fluttertoast.showToast(msg: "Enter valid email");
                            } else {
                              FirebaseAuth.instance.sendPasswordResetEmail(
                                  email: emailController.text);
                              Fluttertoast.showToast(
                                  msg:
                                      "A reset link has been sent to your mail",
                                  timeInSecForIosWeb: 3);
                            }
                          },
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  signinWithEmail({String email, String password, BuildContext context}) {
    FirebaseAuth.instance
        .signInWithEmailAndPassword(email: email, password: password)
        .then((value) async {
      DocumentSnapshot snap =
          await ins.collection('users').document(value.user.uid).get();
      nameController.text = snap['name'];
      emailController.text = snap['email'];
      phoneNumberController.text = snap['phone'];
      addressController.text = snap['address'];
      uid = snap.documentID;
      notification = snap['notificationEnabled'] == 'true';
      setState(() {
        photoURL = snap['photoURL'];
        _loginLoading = false;
      });
      Fluttertoast.showToast(msg: "Sign in success");
      Navigator.pushNamedAndRemoveUntil(context, 'home', (route) => false);
    }).catchError((e) {
      setState(() {
        _loginLoading = false;
      });
      String errorType;
      switch (e.message) {
        case 'There is no user record corresponding to this identifier. The user may have been deleted.':
          errorType = "User Not Found";
          break;
        case 'The password is invalid or the user does not have a password.':
          errorType = "Password Not Valid";
          break;
        case 'A network error (such as timeout, interrupted connection or unreachable host) has occurred.':
          errorType = "Network Error";
          break;
        default:
          print('Case ${e.message} is not yet implemented');
      }
      Fluttertoast.showToast(msg: errorType);
    });
  }

  signinWithGoogle() async {
    GoogleSignIn _googleSignIn = GoogleSignIn();
    GoogleSignInAccount googleUser = await _googleSignIn.signIn();
    //If User cancels G-Signin while selecting email
    if (googleUser != null) {
      bool exisitngEmail = await exisitngUser(googleUser.email);

      GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      AuthCredential credential = GoogleAuthProvider.getCredential(
          accessToken: googleAuth.accessToken, idToken: googleAuth.idToken);
      if (exisitngEmail) {
        await FirebaseAuth.instance
            .signInWithCredential(credential)
            .then((value) async {
          print(value.additionalUserInfo.providerId);
          //If Existing user is Authenticated previously by google
          if (value.additionalUserInfo.providerId == "google.com") {
            DocumentSnapshot snap =
                await ins.collection('users').document(value.user.uid).get();
            nameController.text = snap['name'];
            emailController.text = snap['email'];
            phoneNumberController.text = snap['phone'];
            addressController.text = snap['address'];
            photoURL = snap['photoURL'];
            notification = snap['notificationEnabled'] == 'true';
            uid = snap.documentID;
            if (photoURL == null) photoURL = value.user.photoUrl;
            setState(() {
              _isLogningWithGoogleLoading = false;
            });
            Fluttertoast.showToast(msg: "Signin Success");
            Navigator.pushNamedAndRemoveUntil(
                context, 'home', (route) => false);
          } else {
            setState(() {
              _isLogningWithGoogleLoading = false;
            });
            Fluttertoast.showToast(msg: "Kindly Signin using Email");
          }
        }).catchError((e) {
          setState(() {
            _isLogningWithGoogleLoading = false;
          });
          Fluttertoast.showToast(msg: e.message);
        });
      } else {
        setState(() {
          _isLogningWithGoogleLoading = false;
        });
        Fluttertoast.showToast(msg: "No user corresponding to this email");
      }
    } else {
      setState(() {
        _isLogningWithGoogleLoading = false;
      });
    }
  }

//Checks exisiting user or not
  Future<bool> exisitngUser(String email) async {
    QuerySnapshot snap = await ins
        .collection('users')
        .where('email', isEqualTo: email)
        .getDocuments();
    if (snap.documents.length != 0)
      return true;
    else
      return false;
  }
}
