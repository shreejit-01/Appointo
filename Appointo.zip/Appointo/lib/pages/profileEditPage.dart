import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';

class EditProfilePage extends StatefulWidget {
  EditProfilePage({Key key}) : super(key: key);

  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  FocusNode name = FocusNode(), phone = FocusNode();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 40,
                ),
                Hero(
                  tag: 'tag1',
                  child: CircleAvatar(
                      maxRadius: MediaQuery.of(context).size.width / 4,
                      backgroundImage:
                          photoURL == null ? null : NetworkImage(photoURL),
                      backgroundColor: white,
                      child: photoURL == null
                          ? Text(
                              nameController.text[0],
                              style: TextStyle(fontSize: 100, color: pink),
                            )
                          : null),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 15.0),
                  child: Text(
                    nameController.text,
                    style: Theme.of(context).textTheme.bodyText1,
                  ),
                ),
                Divider(
                  indent: 50,
                  endIndent: 50,
                  thickness: 1,
                  color: Theme.of(context).accentColor,
                ),
                Container(
                    width: MediaQuery.of(context).size.width * 0.8,
                    child: Container(
                      child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 20, horizontal: 20),
                          child: editForm()),
                    ))
              ],
            ),
          ),
          IconButton(
              icon: Icon(
                Icons.arrow_back_ios,
                color: formColor,
              ),
              iconSize: 30,
              padding: EdgeInsets.only(top: 25, left: 20),
              onPressed: () => Navigator.pop(context))
        ]),
      ),
    );
  }

  Widget editForm() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.9,
      child: Column(
        children: [
          editFormField(nameController, 'Name'),
          editFormField(emailController, 'Email'),
          editFormField(phoneNumberController, 'Phone'),
          editFormField(addressController, 'Address'),
        ],
      ),
    );
  }

  editFormField(TextEditingController controller, String field) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            border: Border.all(color: Colors.grey)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: (field == 'Address')
                    ? MediaQuery.of(context).size.width * 0.5
                    : null,
                child: Text(
                  (controller.text.isEmpty) ? field : controller.text,
                  maxLines: (field == 'Address') ? 4 : 1,
                  overflow: TextOverflow.clip,
                  style: Theme.of(context).textTheme.bodyText2,
                ),
              ),
            ),
            (field == 'Email')
                ? Container(
                    height: 47,
                    child: Text(''),
                  )
                : (controller.text == null || controller.text.isEmpty)
                    ? IconButton(
                        icon: Icon(
                          Icons.file_upload,
                          color: Colors.blue,
                        ),
                        onPressed: () {
                          showPopup(
                              controller: addressController,
                              field: field,
                              update: true);
                        })
                    : IconButton(
                        icon: Icon(
                          Icons.edit,
                          color: Colors.blue,
                        ),
                        onPressed: () {
                          showPopup(
                              controller: controller,
                              field: field,
                              update: false);
                        })
          ],
        ),
      ),
    );
  }

  Future<String> showPopup(
      {TextEditingController controller, String field, bool update}) async {
    TextEditingController textEditingController = TextEditingController();
    return await showDialog(
      context: context,
      builder: (context) {
        textEditingController.text = controller.text;
        bool _isLoading = false;
        return AlertDialog(
          title: Text(field),
          content: Container(
            // height: 120,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextFormField(
                  controller: textEditingController,
                  autofocus: true,

                  // style: TextStyle(height: 1.4, color: Colors.black),
                  maxLines: (field == 'Address') ? 4 : 1,

                  textInputAction: TextInputAction.done,
                  keyboardType: (field == 'Phone')
                      ? TextInputType.numberWithOptions()
                      : TextInputType.emailAddress,
                  decoration: InputDecoration(
                    hintStyle: TextStyle(color: Colors.black.withOpacity(0.5)),
                    focusColor: Colors.black,
                    contentPadding: EdgeInsets.only(left: 10),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(5),
                        borderSide: BorderSide(
                            width: 1, color: Theme.of(context).accentColor)),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(5),
                        borderSide: BorderSide(
                            width: 1,
                            color: Theme.of(context)
                                .accentColor
                                .withOpacity(0.5))),
                    focusedErrorBorder: OutlineInputBorder(
                        gapPadding: 0,
                        borderRadius: BorderRadius.circular(5),
                        borderSide: BorderSide(
                            width: 1, color: Theme.of(context).accentColor)),
                    errorBorder: OutlineInputBorder(
                        gapPadding: 0,
                        borderRadius: BorderRadius.circular(5),
                        borderSide: BorderSide(
                            width: 1, color: Theme.of(context).errorColor)),
                  ),
                  validator: (value) {
                    if (value.isEmpty) {
                      return '$field must not be empty';
                    } else
                      return null;
                  },
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    RaisedButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text("Cancel"),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    RaisedButton(
                      onPressed: () async {
                        setState(() {
                          _isLoading = true;
                        });
                        if (textEditingController.text.isNotEmpty) {
                          ins.collection('users').document(uid).updateData({
                            '${field.toLowerCase()}': textEditingController.text
                          });
                          setState(() {
                            if (field == 'Name')
                              nameController.text = textEditingController.text;
                            else if (field == 'Phone')
                              phoneNumberController.text =
                                  textEditingController.text;
                            else if (field == 'Address')
                              addressController.text =
                                  textEditingController.text;
                          });
                          Navigator.pop(context);
                        } else
                          Fluttertoast.showToast(
                              msg: "field must not be empty");
                        setState(() {
                          _isLoading = false;
                        });
                      },
                      child: (_isLoading)
                          ? CircularProgressIndicator()
                          : Text("Update"),
                    ),
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
