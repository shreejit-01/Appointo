import 'dart:async';
import 'package:enterprise/pages/filtersPage.dart';
import 'package:enterprise/services/analytics.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:enterprise/widgets.dart/vendorCard.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fluttertoast/fluttertoast.dart';

//Search Page-> Shows all result if filterCategory is empty
//Search Page-> filter by category if not empty
class SearchPage extends StatefulWidget {
  final List filterCategory;
  SearchPage({Key key, this.filterCategory}) : super(key: key);

  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  GlobalKey<ScaffoldState> _scafKey = GlobalKey<ScaffoldState>();
  List searchResult = [];
  TextEditingController searchController = TextEditingController();
  ScrollController _scrollController = ScrollController();
  List filterCategory = [];
  bool search = false;
  bool querying = false;
  bool listenScroll = true;
  DocumentSnapshot lastDocument;

  int queryLimit = 7;
  Query baseQuery = ins.collection('vendors');

  @override
  void initState() {
    _scrollController.addListener(() {
      scrollEventHandler();
    });
    filterCategory.addAll(widget.filterCategory);
    searchKey();
    super.initState();
  }

  scrollEventHandler() {
    if (_scrollController.position.maxScrollExtent ==
            _scrollController.position.pixels &&
        listenScroll) {
      listenScroll = false;
      searchKey();
    }
  }

//Main search function, automatically gives result based on the searchcontroller and filter categories
  searchKey() async {
    setState(() {
      searchResult.add(null);
      search = false;
    });
    String searchString;
    QuerySnapshot snap;
    Query searchQuery = baseQuery;

    if (searchController.text.isNotEmpty) {
      Analytics().logSearchEvent(searchTerm: searchController.text);
      searchString = searchController.text[0].toUpperCase() +
          searchController.text.substring(1);
      searchQuery = searchQuery
          .orderBy('name')
          .startAt([searchString]).endAt([searchString + '\uf8ff']);
    } else {
      searchQuery = searchQuery.orderBy('name');
    }
    if (filterCategory.isNotEmpty)
      searchQuery =
          searchQuery.where('category', arrayContainsAny: filterCategory);
    else
      searchQuery =
          searchQuery.where('category', arrayContainsAny: categoryList);
    if (!listenScroll) {
      searchQuery = searchQuery.startAfterDocument(lastDocument);
    }
    snap = await searchQuery.limit(queryLimit).getDocuments();
    searchResult.removeLast();

    if (snap.documents.length == 0) {
      listenScroll = false;
    }
    try {
      setState(() {
        searchResult.addAll(snap.documents);
        listenScroll = true;
      });
    } catch (e) {}
    if (searchResult.length != 0)
      lastDocument = searchResult[searchResult.length - 1];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scafKey,
      bottomNavigationBar: BottomNavigationBar(
        items: items,
        type: BottomNavigationBarType.fixed,
        currentIndex: bottomNavIndex,
        selectedItemColor: formColor,
        unselectedItemColor: Colors.grey,
        onTap: (value) {
          setState(() {
            bottomNavIndex = value;
          });
          navAction[value](context);
        },
      ),
      body: WillPopScope(
        onWillPop: () async {
          print("Caalback");
          if (exit) return exit;
          Fluttertoast.showToast(msg: "Press back again, if you want to exit");
          exit = true;
          Timer(Duration(seconds: 3), () {
            exit = false;
          });
          return false;
        },
        child: SafeArea(
          child: Container(
            child: SingleChildScrollView(
              controller: _scrollController,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      searchBar(),
                    ],
                  ),
                  Visibility(
                    visible: search,
                    replacement: results(),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 50),
                      child: Container(
                        alignment: Alignment.center,
                        child: Text(
                          "Type in and Search!",
                          style: TextStyle(color: Colors.grey, fontSize: 20),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget searchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Container(
            height: 50,
            width: MediaQuery.of(context).size.width * .7,
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Theme.of(context).cardColor,
                blurRadius: 3,
              )
            ], borderRadius: BorderRadius.circular(18)),
            child: TextFormField(
              controller: searchController,
              enableSuggestions: true,
              // autofocus: true,
              decoration: InputDecoration(
                hintText: "Search",
                hintStyle: Theme.of(context).textTheme.bodyText2,
                fillColor: Theme.of(context).cardColor,
                filled: true,
                // prefixIcon: IconButton(
                //     icon: Icon(
                //       Icons.search,
                //       color: Colors.blue,
                //     ),
                //     onPressed: searchKey),
                suffixIcon: IconButton(
                    icon: Icon(
                      Icons.clear,
                      color: Colors.grey,
                    ),
                    onPressed: () {
                      setState(() {
                        search = true;
                      });
                      searchResult.clear();
                      searchController.clear();
                      searchKey();
                    }),
                contentPadding: EdgeInsets.symmetric(horizontal: 15),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide(
                      color: Theme.of(context).accentColor.withOpacity(0.5),
                      width: 1,
                      style: BorderStyle.solid),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide(
                      color: Theme.of(context).accentColor.withOpacity(0.5),
                      width: 1,
                      style: BorderStyle.solid),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide(
                      color: Theme.of(context).accentColor.withOpacity(0.5),
                      width: 1,
                      style: BorderStyle.solid),
                ),
              ),
              onChanged: (val) {
                searchResult.clear();
                searchKey();
              },
            ),
          ),
          IconButton(
            icon: Icon(Icons.tune),
            padding: EdgeInsets.all(0),
            color: Theme.of(context).accentColor,
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => FiltersPage(
                      filterCategory: widget.filterCategory,
                    ),
                  ));
            },
          ),
        ],
      ),
    );
  }

  Widget results() {
    return searchResult.length == 0
        ? Center(
            child: Padding(
            padding: const EdgeInsets.all(50.0),
            child: Text("Try with a broader search"),
          ))
        : Container(
            child: Column(
              children: [
                SizedBox(
                  height: 20,
                ),
                SizedBox(
                  height: 15,
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Column(
                    children: List.generate(
                        searchResult.length,
                        (index) => searchResult[index] == null
                            ? Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: CircularProgressIndicator(),
                              )
                            : VendorCard(
                                snap: searchResult[index],
                                // variant:
                                //     colorPalette[index % colorPalette.length],   //used for automatic determination of card color
                              )),
                  ),
                ),
              ],
            ),
          );
  }
}
