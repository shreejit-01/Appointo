import 'dart:async';
import 'package:enterprise/pages/search.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Home extends StatefulWidget {
  Home({Key key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

//Home Scaffold for bottomNavBar except for Search Page
class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        items: items,
        type: BottomNavigationBarType.fixed,
        currentIndex: bottomNavIndex,
        selectedItemColor: formColor,
        unselectedItemColor: Colors.grey,
        onTap: (value) {
          setState(() {
            bottomNavIndex = value;
          });
          if (bottomNavIndex == 2)
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (context) => SearchPage(
                    filterCategory: [],
                  ),
                ),
                (route) => false);
        },
      ),
      body: WillPopScope(
          onWillPop: () async {
            if (exit) return exit;
            Fluttertoast.showToast(
                msg: "Press back again, if you want to exit");
            exit = true;
            Timer(Duration(seconds: 3), () {
              exit = false;
            });
            return false;
          },
          child: navigateTo[bottomNavIndex]),
    );
  }
}
