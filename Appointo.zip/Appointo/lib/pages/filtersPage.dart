import 'package:enterprise/pages/search.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class FiltersPage extends StatefulWidget {
  final List filterCategory;
  FiltersPage({Key key, this.filterCategory}) : super(key: key);

  @override
  _FiltersPageState createState() => _FiltersPageState();
}

class _FiltersPageState extends State<FiltersPage> {
  List filterCategory = [];
  @override
  void initState() {
    filterCategory = widget.filterCategory;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //  bottomNavigationBar: ,
      persistentFooterButtons: [
        RaisedButton(
          onPressed: () {
            filterCategory.clear();
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (context) => SearchPage(
                    filterCategory: filterCategory,
                  ),
                ),
                (route) => false);
          },
          child: Text("clear"),
        ),
        RaisedButton(
          onPressed: () {
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (context) => SearchPage(
                    filterCategory: filterCategory,
                  ),
                ),
                (route) => false);
          },
          child: Text("Apply"),
        ),
      ],
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("Filter",
                  style: GoogleFonts.workSans(
                      fontWeight: FontWeight.w600, fontSize: 20)),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text("Category",
                      style: GoogleFonts.workSans(
                          fontWeight: FontWeight.w400, fontSize: 16)),
                  SizedBox(
                    height: 10,
                  ),
                  Wrap(
                    direction: Axis.horizontal,
                    children: List.generate(
                        categoryList.length,
                        (index) => Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 5, vertical: 5),
                              child: GestureDetector(
                                onTap: () {
                                  if (!filterCategory
                                      .contains(categoryList[index]))
                                    setState(() {
                                      filterCategory.add(categoryList[index]);
                                    });
                                  else
                                    setState(() {
                                      filterCategory
                                          .remove(categoryList[index]);
                                    });
                                },
                                child: Container(
                                  width: 150,
                                  decoration: BoxDecoration(
                                      color: Theme.of(context).cardColor,
                                      border: Border.all(
                                          color: filterCategory
                                                  .contains(categoryList[index])
                                              ? Colors.blue
                                              : white,
                                          width: 2),
                                      borderRadius: BorderRadius.circular(5),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.grey,
                                          blurRadius: 1,
                                        ),
                                      ]),
                                  child: Row(
                                    // mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(3.0),
                                        child: (categoryIconList == null ||
                                                categoryIconList.length <=
                                                    index)
                                            ? Icon(Icons.card_giftcard,
                                                size: 45,
                                                color: Theme.of(context)
                                                    .accentColor
                                                    .withOpacity(0.5))
                                            : Container(
                                                height: 45,
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(5),
                                                  child: Image.network(
                                                      categoryIconList[index]),
                                                )),
                                      ),
                                      Container(
                                        width: 80,
                                        child: Text(
                                          categoryList[index].toString(),
                                          textAlign: TextAlign.left,
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 3,
                                          style: Theme.of(context)
                                              .textTheme
                                              .headline1,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            )),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
