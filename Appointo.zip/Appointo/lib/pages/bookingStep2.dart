import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:enterprise/pages/bookingStep3.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:jiffy/jiffy.dart';
import 'package:fluttertoast/fluttertoast.dart';

class BookingStep2 extends StatefulWidget {
  final DocumentSnapshot snap;
  final List selectedServices;
  BookingStep2({Key key, this.snap, this.selectedServices}) : super(key: key);

  @override
  _BookingStep2State createState() => _BookingStep2State();
}

class _BookingStep2State extends State<BookingStep2> {
  CalendarController _calendarController = CalendarController();
  List<String> days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  List<int> holiDays = [];
  List<String> timeList = [];
  String selectedTime = '';
  DateTime selectedDate = DateTime.now();
  @override
  void initState() {
    generateSelectableDays();
    createTimeList();
    super.initState();
  }

  generateSelectableDays() {
    List<int> workDays = [1, 2, 3, 4, 5, 6, 7];
    List availableDaysofWeek = widget.snap['availableDaysofWeek'];
    availableDaysofWeek = [0, 1, 2, 3];
    availableDaysofWeek.forEach((element) {
      if (workDays.contains(element + 1)) workDays.remove(element + 1);
      // workDays.add(element + 1);
    });
    setState(() {
      holiDays = workDays;
    });
    print(availableDaysofWeek.toString() + '\n' + holiDays.toString());
  }

  createTimeList() {
    List services = widget.snap['services'];
    widget.selectedServices.forEach((element) {
      List time = services[element]['availableTime'].toString().split(",");
      time.forEach((element) {
        if (!timeList.contains(element)) timeList.add(element);
      });
    });
    setState(() {
      selectedTime = timeList[0];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Stack(
                  alignment: Alignment.topRight,
                  children: [
                    Center(
                      child: Container(
                        height: MediaQuery.of(context).size.height * .4,
                        width: MediaQuery.of(context).size.width * .8,
                        child: Image.asset(
                          'assets/step.png',
                          fit: BoxFit.fitWidth,
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          icon: Icon(
                            Icons.arrow_back_ios,
                            color: Colors.blue,
                          ),
                          iconSize: 30,
                          padding: EdgeInsets.all(10),
                          onPressed: () => Navigator.pop(context),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: List.generate(3, (index) {
                              return Container(
                                width: 20.0,
                                height: 20.0,
                                margin: EdgeInsets.symmetric(
                                    vertical: 15.0, horizontal: 8.0),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: Theme.of(context).accentColor),
                                  color: 1 >= index
                                      ? Theme.of(context).accentColor
                                      : Theme.of(context).primaryColor,
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
                Column(
                  children: [
                    Text("Step 2 : select the date and time",
                        maxLines: 2, style: GoogleFonts.workSans(fontSize: 20)),
                    SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: TableCalendar(
                        calendarController: _calendarController,
                        availableGestures: AvailableGestures.horizontalSwipe,
                        formatAnimation: FormatAnimation.slide,
                        weekendDays: holiDays,
                        onUnavailableDaySelected: () {
                          Fluttertoast.showToast(msg: "not available");
                        },
                        enabledDayPredicate: (day) =>
                            (day.compareTo(DateTime.now()) > 0)
                                ? !holiDays.contains(day.weekday)
                                : false,
                        initialCalendarFormat: CalendarFormat.month,
                        availableCalendarFormats: const {
                          CalendarFormat.month: ''
                        },
                        onDaySelected: (day, events) {
                          setState(() {
                            selectedDate = day;
                          });
                        },
                        calendarStyle: CalendarStyle(
                            markersColor: Colors.blue,
                            unavailableStyle: TextStyle(
                              color: Colors.red.withOpacity(0.5),
                            ),
                            selectedColor: Colors.blue),
                        headerStyle: HeaderStyle(
                            leftChevronIcon: Icon(
                              Icons.chevron_left,
                              color: Theme.of(context).accentColor,
                            ),
                            rightChevronIcon: Icon(
                              Icons.chevron_right,
                              color: Theme.of(context).accentColor,
                            )),
                        startDay: DateTime.now(),
                      ),
                    )
                  ],
                ),
                timeSelector(),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text(
                          "${Jiffy(selectedDate).format('do MMMM yyyy')} $selectedTime",
                          style: GoogleFonts.workSans(
                              fontSize: 17, color: Colors.grey)),
                      RaisedButton(
                          onPressed: () {
                            if ((DateTime.now().compareTo(DateTime.parse(
                                        selectedDate
                                                .toString()
                                                .substring(0, 11) +
                                            selectedTime)) <
                                    0) &&
                                !holiDays.contains(selectedDate.weekday))
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => BookingStep3(
                                        snap: widget.snap,
                                        selectedTime: selectedTime,
                                        selectedDate: selectedDate,
                                        selectedServices:
                                            widget.selectedServices),
                                  ));
                            else {
                              Fluttertoast.showToast(msg: "Invalid Date");
                            }
                          },
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5)),
                          color: Colors.red.withOpacity(.9),
                          padding: EdgeInsets.symmetric(
                              horizontal: 30, vertical: 10),
                          child: Text("Next",
                              style: GoogleFonts.workSans(
                                  fontSize: 30, color: Colors.white)))
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  timeSelector() {
    return Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
        child: Wrap(
          alignment: WrapAlignment.start,
          direction: Axis.horizontal,
          crossAxisAlignment: WrapCrossAlignment.start,
          children: List.generate(
              timeList.length,
              (index) => Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedTime = timeList[index];
                        });
                      },
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: timeList[index] == selectedTime
                                ? Colors.blue
                                : Colors.white),
                        padding: EdgeInsets.all(7),
                        child: Text(
                          timeList[index],
                          style: GoogleFonts.nanumGothicCoding(
                              fontSize: 16,
                              color: timeList[index] == selectedTime
                                  ? Colors.white
                                  : Colors.black),
                        ),
                      ),
                    ),
                  )),
        ));
  }
}
