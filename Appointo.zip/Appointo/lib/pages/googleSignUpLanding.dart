import 'package:enterprise/utils/constants.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter/material.dart';

class GoogleSignUpLandingPage extends StatefulWidget {
  GoogleSignUpLandingPage({Key key}) : super(key: key);

  @override
  _GoogleSignUpLandingPageState createState() =>
      _GoogleSignUpLandingPageState();
}

class _GoogleSignUpLandingPageState extends State<GoogleSignUpLandingPage> {
  final _formKey = GlobalKey<FormState>();
  bool _isSignUpLoading = false;
  FocusNode name = FocusNode(), phone = FocusNode();
  @override
  void dispose() {
    FirebaseAuth.instance.signOut();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: formColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Center(
            child: SingleChildScrollView(
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width * 0.3,
                      child: Hero(
                        tag: 'vec',
                        child: Image(
                          image: AssetImage("assets/google_logo.png"),
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    signupForm(),
                    SizedBox(
                      height: 20,
                    ),
                    _isSignUpLoading
                        ? Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              child: CircularProgressIndicator(),
                            ),
                          )
                        : Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.8,
                              child: MaterialButton(
                                color: white,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20)),
                                onPressed: () {
                                  setState(() {
                                    _isSignUpLoading = true;
                                  });
                                  if (_formKey.currentState.validate()) {
                                    signupWithGoogle();
                                  } else {
                                    setState(() {
                                      _isSignUpLoading = false;
                                    });
                                  }
                                },
                                child: Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 10),
                                  child: Text(
                                    'SIGNUP',
                                    style: TextStyle(
                                        fontSize: 18, color: formColor),
                                  ),
                                ),
                              ),
                            ),
                          )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  signupForm() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.8,
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Container(
              height: 94,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8, left: 1),
                    child: Text(
                      "Name",
                      style: TextStyle(color: white, fontSize: 14),
                    ),
                  ),
                  TextFormField(
                    controller: nameController,
                    focusNode: name,
                    style: TextStyle(height: 1.4, color: white),
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      hintText: "Enter Your Name",
                      hintStyle: TextStyle(color: white.withOpacity(0.5)),
                      focusColor: white,
                      prefixIcon: Icon(
                        Icons.account_circle,
                        color: white.withOpacity(0.8),
                      ),
                      contentPadding: EdgeInsets.only(left: 10),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: white)),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(
                              width: 1, color: white.withOpacity(0.5))),
                      focusedErrorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                      errorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                    ),
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Name must not be empty';
                      } else
                        return null;
                    },
                    onFieldSubmitted: (value) {
                      phone.requestFocus();
                    },
                  ),
                ],
              ),
            ),
            Container(
              height: 94,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8, left: 1),
                    child: Text(
                      "Email",
                      style: TextStyle(color: white, fontSize: 14),
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: white.withOpacity(0.5))),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10, horizontal: 10),
                          child:
                              Icon(Icons.email, color: white.withOpacity(0.8)),
                        ),
                        Text(
                          emailController.text,
                          style: TextStyle(color: white.withOpacity(0.8)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 94,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8, left: 1),
                    child: Text(
                      "Phone No",
                      style: TextStyle(color: white, fontSize: 14),
                    ),
                  ),
                  TextFormField(
                    controller: phoneNumberController,
                    focusNode: phone,
                    keyboardType: TextInputType.numberWithOptions(),
                    textInputAction: TextInputAction.done,
                    style: TextStyle(height: 1.4, color: white),
                    decoration: InputDecoration(
                      hintText: "Enter Your Phone no",
                      hintStyle: TextStyle(color: white.withOpacity(0.5)),
                      focusColor: white,
                      prefixIcon: Icon(
                        Icons.phone,
                        color: white.withOpacity(0.8),
                      ),
                      contentPadding: EdgeInsets.only(left: 10),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: white)),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(
                              width: 1, color: white.withOpacity(0.5))),
                      focusedErrorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                      errorBorder: OutlineInputBorder(
                          gapPadding: 0,
                          borderRadius: BorderRadius.circular(5),
                          borderSide: BorderSide(width: 1, color: Colors.red)),
                    ),
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Phone number must not be empty';
                      } else
                        return null;
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  signupWithGoogle() async {
    await ins.collection('users').document(uid).setData({
      'name': nameController.text,
      'email': emailController.text,
      'phone': phoneNumberController.text,
      'photoURL': photoURL,
      'notificationEnabled': 'true'
    }).then((value) {
      setState(() {
        _isSignUpLoading = true;
      });
      Fluttertoast.showToast(msg: "Signup Success");
      Navigator.pushNamedAndRemoveUntil(context, 'home', (route) => false);
    }).catchError((onError) {
      Fluttertoast.showToast(msg: onError.message);
      setState(() {
        _isSignUpLoading = true;
      });
    });
  }
}
