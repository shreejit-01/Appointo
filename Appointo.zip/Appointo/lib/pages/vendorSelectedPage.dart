import 'dart:ui';
import 'package:enterprise/pages/bookingStep1.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:enterprise/widgets.dart/imageSlider.dart';
import 'package:enterprise/widgets.dart/reviewCard.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geoflutterfire/geoflutterfire.dart';

class VendorDetails extends StatefulWidget {
  final DocumentSnapshot snap;
  VendorDetails({Key key, this.snap}) : super(key: key);

  @override
  _VendorDetailsState createState() => _VendorDetailsState();
}

class _VendorDetailsState extends State<VendorDetails>
    with SingleTickerProviderStateMixin {
  CarouselController _carouselController = CarouselController();
  PageStorageKey<dynamic> _pageStorageKey;
  ScrollController _scrollController = ScrollController();
  int _current = 0;
  List<DocumentSnapshot> reviewList = [];
  DocumentSnapshot lastdocument;
  bool listenScroll = true, nothingToShow = false;
  List<DocumentSnapshot> alternativesList;

  TabController _tabController;
  List typesofServicesList;
  int reviewQuerylimit = 6;
  List<String> _tabs = ['Services', 'Location', 'Reviews'];
  // bool _selected = false;
  @override
  void initState() {
    _tabController = TabController(length: _tabs.length, vsync: this);
    getAlternatives();
    getReviewList();
    super.initState();
  }

  getAlternatives() async {
    QuerySnapshot value = await ins
        .collection('vendors')
        .where('category', arrayContainsAny: widget.snap['category'])
        .limit(8)
        .getDocuments();
    setState(() {
      alternativesList = value.documents;
    });

    if (alternativesList.length > 1) {
      alternativesList.forEach((element) {
        if (element.documentID == widget.snap.documentID)
          setState(() {
            alternativesList.remove(widget.snap);
          });
      });
    } else
      alternativesList.clear();
    if (alternativesList.length < 8) {
      QuerySnapshot val = await ins
          .collection('vendors')
          .limit(8 - alternativesList.length)
          .getDocuments()
          .then((value) {
        setState(() {
          alternativesList.addAll(value.documents);
        });
        return value;
      });
      alternativesList.removeWhere(
          (element) => element.documentID == widget.snap.documentID);
    }
    // if (alternativesList.length < 8) {
    //   QuerySnapshot more = await ins
    //       .collection('vendors')
    //       .startAfterDocument(alternativesList.last)
    //       .limit(8 - alternativesList.length)
    //       .getDocuments();
    //   setState(() {
    //     alternativesList.addAll(more.documents);
    //   });
    // }
  }

  getReviewList() async {
    ins
        .collection('reviews')
        .where('uid', isEqualTo: widget.snap.documentID)
        .orderBy('rating', descending: true)
        .limit(reviewQuerylimit)
        .getDocuments()
        .then((value) {
      setState(() {
        reviewList.addAll(value.documents);
      });

      if (reviewList.length != 0) {
        lastdocument = reviewList.last;
      } else
        setState(() {
          nothingToShow = true;
        });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        items: items,
        type: BottomNavigationBarType.fixed,
        currentIndex: bottomNavIndex,
        selectedItemColor: formColor,
        unselectedItemColor: Colors.grey,
        onTap: (value) {
          setState(() {
            bottomNavIndex = value;
          });
          navAction[value](context);
        },
      ),
      body:
          // _selected
          //     ? navigateTo[bottomNavIndex]
          //     :
          SafeArea(
              child: Container(
        height: MediaQuery.of(context).size.height,
        child: Column(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius:
                      BorderRadius.vertical(bottom: Radius.circular(15)),
                  boxShadow: [
                    BoxShadow(
                        blurRadius: 2, color: Theme.of(context).canvasColor)
                  ]),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    // crossAxisAlignment: CrossAxisAlignment.start,
                    // crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(40),
                        ),
                        child: Align(
                          alignment: Alignment.bottomRight,
                          heightFactor: 0.85,
                          widthFactor: 0.79,
                          child: CircleAvatar(
                            radius:
                                MediaQuery.of(context).size.width * 0.57 / 2.5,
                            backgroundImage: NetworkImage(widget.snap['logo']),
                            // child: Image.network(
                            //   widget.snap['logo'],
                            //   alignment: Alignment.topLeft,
                            //   height: MediaQuery.of(context).size.width * 0.65,
                            //   width: MediaQuery.of(context).size.width * 0.57,
                            //   fit: BoxFit.cover,
                            // ),
                          ),
                        ),
                      ),
                      Container(
                        // width: MediaQuery.of(context).size.width * 0.6,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width * 0.6,
                              child: Text(
                                widget.snap['name'],
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.workSans(
                                  fontSize: 20,
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Row(
                              children: [
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.3,
                                  child: Wrap(
                                    // crossAxisAlignment:
                                    //     CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        widget.snap['category'][0],
                                        style:
                                            GoogleFonts.workSans(fontSize: 13),
                                      ),
                                      widget.snap['rating'] == null
                                          ? Container()
                                          : RatingBar(
                                              itemBuilder: (context, index) =>
                                                  Icon(
                                                Icons.star,
                                                color: Colors.amber,
                                              ),
                                              glowColor: Colors.amber,
                                              ignoreGestures: true,
                                              itemCount: 5,
                                              minRating: 3,
                                              glow: true,
                                              unratedColor: Colors.grey,
                                              maxRating: 5,
                                              initialRating: double.parse(widget
                                                  .snap['rating']
                                                  .toString()),
                                              onRatingUpdate: (double value) {},
                                              itemSize: 15,
                                              itemPadding:
                                                  EdgeInsets.only(right: 1),
                                            ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width: 1,
                                  height: 40,
                                  color: Theme.of(context).accentColor,
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.3,
                                  child: Wrap(
                                    runAlignment: WrapAlignment.center,
                                    children: [
                                      Text(
                                        "Contact",
                                        overflow: TextOverflow.ellipsis,
                                        style:
                                            GoogleFonts.workSans(fontSize: 13),
                                      ),
                                      Text(
                                        widget.snap['contact'],
                                        style:
                                            GoogleFonts.workSans(fontSize: 13),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  height: 30,
                                  child: MaterialButton(
                                    onPressed: () => Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => BookingStep1(
                                            snap: widget.snap,
                                          ),
                                        )),
                                    color: Colors.blue,
                                    child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.5,
                                        alignment: Alignment.center,
                                        child: Text(
                                          "Book Now",
                                          style: TextStyle(color: Colors.white),
                                        )),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                  Divider(
                    color: Theme.of(context).accentColor,
                  ),
                  TabBar(
                    tabs: List.generate(
                        _tabs.length,
                        (index) => Container(
                            padding: EdgeInsets.all(5),
                            child: Text(_tabs[index],
                                style: GoogleFonts.workSans(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w400)))),
                    controller: _tabController,
                    indicatorColor: Colors.blue,
                    indicatorWeight: 3,
                  ),
                ],
              ),
            ),
            Expanded(
              // height: double.maxFinite,
              child: TabBarView(
                  physics: NeverScrollableScrollPhysics(),
                  controller: _tabController,
                  children: [
                    services(),
                    location(),
                    review(),
                  ]),
            ),
          ],
        ),
      )),
    );
  }

  Widget services() {
    typesofServicesList = widget.snap['services'];
    return SingleChildScrollView(
      child: Column(children: [
        ImageSlider(
          imageList: imageList,
        ),
        SizedBox(
          height: 10,
        ),
        Container(
            // decoration: BoxDecoration(
            //     color: white,
            //     borderRadius: BorderRadius.vertical(top: Radius.circular(23))),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 20, top: 10, bottom: 10),
                  child: Text(
                    "Services",
                    style: GoogleFonts.workSans(
                        fontSize: 18, fontWeight: FontWeight.w500),
                  ),
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      SizedBox(
                        width: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: List.generate(
                            typesofServicesList.length,
                            (index) => GestureDetector(
                                  onTap: () {
                                    serviceDetails(index, typesofServicesList);
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Container(
                                      width: 109,
                                      height: 194,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                              height: 130,
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(7),
                                                child: Image.network(
                                                  typesofServicesList[index]
                                                      ['photoUrl'],
                                                  fit: BoxFit.fill,
                                                ),
                                              )),
                                          Text(
                                              typesofServicesList[index]
                                                  ['serviceName'],
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                              overflow: TextOverflow.clip,
                                              style: GoogleFonts.workSans(
                                                fontWeight: FontWeight.w500,
                                              )),
                                          Text(
                                              typesofServicesList[index]
                                                  ['price'],
                                              textAlign: TextAlign.center,
                                              style: GoogleFonts.workSans(
                                                  color: Colors.grey)),
                                        ],
                                      ),
                                    ),
                                  ),
                                )),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
          alternatives()
        ]))
      ]),
    );
  }

  serviceDetails(index, serviceList) {
    // List<String> serviceAvailableDays, serviceAvailableTime;
    // serviceList.forEach((ele){
    //   ele['availableDays']
    // });
    return showDialog(
      context: context,
      builder: (context) {
        return Scaffold(
          backgroundColor: Theme.of(context).accentColor.withOpacity(0.4),
          body: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
            child: Container(
              child: Stack(
                alignment: Alignment.topLeft,
                children: [
                  Center(
                    child: CarouselSlider(
                      options: CarouselOptions(
                        carouselController: _carouselController,
                        height: MediaQuery.of(context).size.height * .9,
                        initialPage: index,
                        pageViewKey: _pageStorageKey,
                        enableInfiniteScroll: false,
                        enlargeCenterPage: true,
                        onPageChanged: (index, reason) {
                          setState(() {
                            _current = index;
                          });
                        },
                      ),
                      items: List.generate(
                        serviceList.length,
                        (index) => Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(height: 30),
                            Expanded(
                              flex: 5,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: Image.network(
                                  serviceList[index]['photoUrl'],
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 4,
                              child: Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(serviceList[index]['serviceName'],
                                        textAlign: TextAlign.center,
                                        style: GoogleFonts.workSans(
                                            fontSize: 30, color: Colors.white)),
                                    Text(
                                      "Avaliable on ${serviceList[index]['availableDays']} at ${serviceList[index]['availableTime']} only",
                                      textAlign: TextAlign.center,
                                      maxLines: 3,
                                      style: GoogleFonts.workSans(
                                          fontSize: 17, color: Colors.white),
                                    ),
                                    Text(
                                      serviceList[index]['price'],
                                      style: GoogleFonts.workSans(
                                          fontSize: 35, color: Colors.white),
                                    ),
                                    Text(
                                      serviceList[index]['description'],
                                      textAlign: TextAlign.center,
                                      maxLines: 3,
                                      style: GoogleFonts.workSans(
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      Icons.arrow_back_ios,
                      color: Colors.blue,
                    ),
                    iconSize: 30,
                    padding: EdgeInsets.all(10),
                    onPressed: () => Navigator.pop(context),
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget alternatives() {
    return Container(
      child: Column(
        children: [
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 20, top: 20, bottom: 10),
                child: Text(
                  "Alternatives",
                  style: GoogleFonts.workSans(
                      fontSize: 18, fontWeight: FontWeight.w500),
                ),
              ),
            ],
          ),
          alternativesList == null
              ? CircularProgressIndicator()
              : Container(
                  height: 250,
                  child: GridView(
                    scrollDirection: Axis.horizontal,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2, childAspectRatio: .5),
                    children: List.generate(alternativesList.length,
                        (index) => alternativesCard(alternativesList[index])),
                  ),
                ),
        ],
      ),
    );
  }

  Widget alternativesCard(DocumentSnapshot alt) {
    return GestureDetector(
      onTap: () => Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => VendorDetails(
              snap: alt,
            ),
          )),
      child: Padding(
        padding: const EdgeInsets.all(4.0),
        child: Container(
          decoration: BoxDecoration(
              color: Colors.white,
              gradient: SweepGradient(
                  colors: [
                    Theme.of(context).cardColor,
                    alt.data['logoBgColor'] == null
                        ? Colors.blue
                        : Color(int.parse(alt.data['logoBgColor']))
                  ],
                  endAngle: 3.141,
                  startAngle: 1.571,
                  center: Alignment.centerLeft,
                  tileMode: TileMode.clamp),
              boxShadow: [
                BoxShadow(blurRadius: 3, color: Colors.grey),
              ],
              borderRadius: BorderRadius.circular(8)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                width: 5,
              ),
              (alt.data['logo'] == null)
                  ? Icon(
                      Icons.card_travel,
                      size: 40,
                    )
                  : CircleAvatar(
                      // height: 40,
                      radius: MediaQuery.of(context).size.width / 8,
                      backgroundImage: NetworkImage(alt.data['logo']),
                    ),
              SizedBox(
                width: 5,
              ),
              Container(
                width: MediaQuery.of(context).size.width / 2.6,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      alt.data['name'],
                      style: GoogleFonts.openSans(
                          fontSize: 16, color: Colors.white),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      // textAlign: TextAlign.left,
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          alt.data['category'][0],
                          style: GoogleFonts.jacquesFrancois(fontSize: 14),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            alt.data['rating'] == null
                                ? Container()
                                : RatingBar(
                                    itemBuilder: (context, index) => Icon(
                                      Icons.star,
                                      color: Colors.amber,
                                    ),
                                    glowColor: Colors.amber,
                                    ignoreGestures: true,
                                    itemCount: 5,
                                    minRating: 3,
                                    glow: true,
                                    unratedColor: Colors.grey,
                                    maxRating: 5,
                                    initialRating: double.parse(
                                        alt.data['rating'].toString()),
                                    onRatingUpdate: (double value) {},
                                    itemSize: 13,
                                    itemPadding: EdgeInsets.only(right: 6),
                                  ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget location() {
    Geoflutterfire geo = Geoflutterfire();
    GeoPoint point = widget.snap.data['geoData']['geopoint'];
    double lat = point.latitude, long = point.longitude;
    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        GoogleMap(
          zoomControlsEnabled: false,
          myLocationButtonEnabled: true,
          initialCameraPosition:
              CameraPosition(target: LatLng(lat, long), zoom: 8),
          // onMapCreated: (controller) {
          //   controller.animateCamera(CameraUpdate.newCameraPosition(
          //       CameraPosition(target: LatLng(lat, long), zoom: 10)));
          // },
          markers: {
            Marker(markerId: MarkerId('SB'), position: LatLng(lat, long))
          },
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            RaisedButton(
              onPressed: () {
                getDirection(lat, long);
              },
              padding: EdgeInsets.all(4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Image.asset(
                    'assets/getdirection.png',
                    color: Colors.white,
                  ),
                  Text("Get Directions",
                      style: GoogleFonts.workSans(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w500)),
                ],
              ),
            ),
            RaisedButton(
              onPressed: () {
                openMap(lat, long);
              },
              padding: EdgeInsets.all(4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  FaIcon(
                    FontAwesomeIcons.map,
                    color: Colors.white,
                  ),
                  Text("Open in Maps",
                      style: GoogleFonts.workSans(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w500)),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Future<void> getDirection(double latitude, double longitude) async {
    if (position == null) {
      openMap(latitude, longitude);
    } else {
      String googleUrl =
          'https://www.google.com/maps/dir/?api=1&origin=${position.latitude},${position.longitude}&destination=$latitude,$longitude'; //&waypoints=43.1941283,-79.59179|43.7991083,-79.5339667|43.8387033,-79.3453417|43.836424,-79.3024487&travelmode=driving&dir_action=navigate';
      if (await canLaunch(googleUrl)) {
        await launch(googleUrl);
      } else {
        throw 'Could not open the map.';
      }
    }
  }

  Future<void> openMap(double latitude, double longitude) async {
    String googleUrl =
        'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude';
    if (await canLaunch(googleUrl)) {
      await launch(googleUrl);
    } else {
      throw 'Could not open the map.';
    }
  }

  Widget review() {
    _scrollController.addListener(() {
      if (_scrollController.position.maxScrollExtent ==
              _scrollController.position.pixels &&
          listenScroll) {
        listenScroll = false;
        ins
            .collection('reviews')
            .where('uid', isEqualTo: widget.snap.documentID)
            .orderBy('rating', descending: true)
            .startAfterDocument(lastdocument)
            .limit(reviewQuerylimit)
            .getDocuments()
            .then((value) {
          setState(() {
            reviewList.addAll(value.documents);
          });
          lastdocument = reviewList.last;
          listenScroll = true;
        });
      }
    });
    return SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        children: reviewList.length == 0
            ? nothingToShow == true
                ? [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 30),
                      child: Text("No reviews yet"),
                    )
                  ]
                : [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CircularProgressIndicator(),
                    )
                  ]
            : List.generate(
                reviewList.length,
                (index) => ReviewCard(
                      snap: reviewList[index],
                    )),
      ),
    );
  }
}
