import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../utils/constants.dart';
import 'package:package_info/package_info.dart';
import 'package:geolocator/geolocator.dart';

class SplashScreen extends StatefulWidget {
  SplashScreen({Key key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    getLocation();
    getDocs();
    splashTimer();
    super.initState();
  }

  getLocation() async {
    position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    print("Postion obtained:\n\n" + position.toJson().toString());
  }

  splashTimer() {
    Timer(Duration(seconds: 3), () {
      FirebaseAuth.instance.currentUser().then((value) {
        if (value != null)
          Navigator.pushNamedAndRemoveUntil(context, 'home', (route) => false);
        else
          Navigator.of(context).pushReplacementNamed('login');
      });
    });
  }

//Populats local varibles
  getDocs() async {
    FirebaseUser user = await FirebaseAuth.instance.currentUser();
    if (user != null) {
      DocumentSnapshot snap =
          await ins.collection('users').document(user.uid).get();
      nameController.text = snap['name'];
      emailController.text = snap['email'];
      phoneNumberController.text = snap['phone'];
      addressController.text = snap['address'];
      photoURL = snap['photoURL'];
      uid = snap.documentID;
      notification = snap['notificationEnabled'] == 'true';
    }

    //gets app version
    var pkginfo = await PackageInfo.fromPlatform();
    version = pkginfo.version;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: TweenAnimationBuilder(
          duration: Duration(seconds: 5),
          tween: Tween<double>(begin: 0, end: 2 * pi),
          builder: (BuildContext context, value, Widget child) {
            return Transform.rotate(
              angle: value,
              child: Icon(
                Icons.settings,
                size: 200,
                color: Theme.of(context).accentColor,
              ),
            );
          },
        ),
      ),
    );
  }
}
