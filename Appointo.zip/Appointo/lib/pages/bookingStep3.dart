import 'package:enterprise/pages/dashboard.dart';
import 'package:enterprise/pages/done.dart';
import 'package:enterprise/services/pushNotification.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../services/analytics.dart';

class BookingStep3 extends StatefulWidget {
  final DocumentSnapshot snap;
  final String selectedTime;
  final DateTime selectedDate;
  final List selectedServices;
  BookingStep3(
      {Key key,
      this.snap,
      this.selectedTime,
      this.selectedDate,
      this.selectedServices})
      : super(key: key);

  @override
  _BookingStep3State createState() => _BookingStep3State();
}

class _BookingStep3State extends State<BookingStep3> {
  GlobalKey<ScaffoldState> _scafKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();

  TextEditingController name = TextEditingController();
  TextEditingController address = TextEditingController();
  TextEditingController mobile = TextEditingController();

  FocusNode nameFocus = FocusNode(),
      addressFocus = FocusNode(),
      mobileFocus = FocusNode();
  bool bookforselfLoading = false, booking = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scafKey,
      body: SafeArea(
        child: Container(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Stack(
                  alignment: Alignment.topRight,
                  children: [
                    Center(
                      child: Container(
                        height: MediaQuery.of(context).size.height * .4,
                        width: MediaQuery.of(context).size.width * .8,
                        child: Image.asset(
                          'assets/step.png',
                          fit: BoxFit.fitWidth,
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          icon: Icon(
                            Icons.arrow_back_ios,
                            color: Colors.blue,
                          ),
                          iconSize: 30,
                          padding: EdgeInsets.all(10),
                          onPressed: () => Navigator.pop(context),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: List.generate(3, (index) {
                              return Container(
                                width: 20.0,
                                height: 20.0,
                                margin: EdgeInsets.symmetric(
                                    vertical: 15.0, horizontal: 8.0),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: Theme.of(context).accentColor),
                                  color: 3 >= index
                                      ? Theme.of(context).accentColor
                                      : Theme.of(context).primaryColor,
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
                Text("Step 3 : fill in the details",
                    style: GoogleFonts.workSans(fontSize: 20)),
                Container(
                  child: Column(
                    children: [
                      bookforselfLoading
                          ? CircularProgressIndicator()
                          : RaisedButton(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              color: Colors.blue,
                              onPressed: () {
                                setState(() {
                                  bookforselfLoading = true;
                                });
                                if (addressController.text.isNotEmpty)
                                  bookForSelf();
                                else {
                                  Fluttertoast.showToast(
                                      msg:
                                          "update your address in the profile to continue");
                                  setState(() {
                                    bookforselfLoading = false;
                                  });
                                  Navigator.pushNamed(
                                      context, 'EditProfilePage');
                                }
                              },
                              child: Container(
                                width: MediaQuery.of(context).size.width * 0.6,
                                height: 45,
                                alignment: Alignment.center,
                                child: Text(
                                  "Book for Self",
                                  style: TextStyle(color: white, fontSize: 18),
                                ),
                              ),
                            ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Column(
                              children: [
                                Container(
                                    width: MediaQuery.of(context).size.width *
                                        .85 /
                                        2,
                                    child: Divider(
                                      thickness: 1,
                                      color: Colors.grey,
                                    )),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text("Or"),
                            ),
                            Column(
                              children: [
                                Container(
                                    width: MediaQuery.of(context).size.width *
                                        .85 /
                                        2,
                                    child: Divider(
                                      thickness: 1,
                                      color: Colors.grey,
                                    )),
                              ],
                            ),
                          ],
                        ),
                      ),
                      form(),
                      SizedBox(
                        height: 30,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 18),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            booking
                                ? CircularProgressIndicator()
                                : RaisedButton(
                                    onPressed: () {
                                      setState(() {
                                        booking = true;
                                      });
                                      if (_formKey.currentState.validate()) {
                                        if (addressController.text.isNotEmpty)
                                          bookService();
                                        else
                                          Fluttertoast.showToast(
                                              msg:
                                                  "update your address in the profile to continue");
                                      } else {
                                        Fluttertoast.showToast(
                                            msg: "all fields required");

                                        setState(() {
                                          booking = false;
                                        });
                                      }
                                    },
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(5)),
                                    color: Colors.red.withOpacity(.9),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 30, vertical: 10),
                                    child: Text("Done",
                                        style: GoogleFonts.workSans(
                                            fontSize: 30, color: Colors.white)))
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget form() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Container(
        height: 243,
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextFormField(
                  controller: name,
                  focusNode: nameFocus,
                  decoration: InputDecoration(
                      labelText: "Name",
                      labelStyle:
                          TextStyle(color: Theme.of(context).accentColor),
                      focusedErrorBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Theme.of(context).errorColor)),
                      errorBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Theme.of(context).errorColor)),
                      enabledBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Theme.of(context).accentColor)),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Theme.of(context).accentColor))),
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Name must not be empty';
                    } else
                      return null;
                  },
                  onFieldSubmitted: (value) {
                    mobileFocus.requestFocus();
                  },
                ),
                TextFormField(
                  controller: mobile,
                  focusNode: mobileFocus,
                  keyboardType: TextInputType.numberWithOptions(),
                  decoration: InputDecoration(
                      labelText: "Mobile Number",
                      labelStyle:
                          TextStyle(color: Theme.of(context).accentColor),
                      focusedErrorBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Theme.of(context).errorColor)),
                      errorBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Theme.of(context).errorColor)),
                      enabledBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Theme.of(context).accentColor)),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Theme.of(context).accentColor))),
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Mobile number must not be empty';
                    } else
                      return null;
                  },
                  onFieldSubmitted: (value) {
                    addressFocus.requestFocus();
                  },
                ),
                TextFormField(
                  controller: address,
                  focusNode: addressFocus,
                  // textInputAction: TextInputAction.newline,
                  decoration: InputDecoration(
                      labelText: "Address",
                      labelStyle:
                          TextStyle(color: Theme.of(context).accentColor),
                      focusedErrorBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Theme.of(context).errorColor)),
                      errorBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Theme.of(context).errorColor)),
                      enabledBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Theme.of(context).accentColor)),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Theme.of(context).accentColor))),
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Address must not be empty';
                    } else
                      return null;
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  bookService() async {
    String fcmToken = await PushNotificationsManager().getToken();
    var time = DateTime.now().millisecondsSinceEpoch;
    List servicesBooked = [];
    widget.selectedServices.forEach((ele) {
      servicesBooked.add(widget.snap['services'][ele]);
    });
    Map<String, dynamic> data = {
      'by': name.text,
      'time': widget.selectedTime,
      'date':
          widget.selectedDate.toString().substring(0, 11) + widget.selectedTime,
      'timeStamp': time,
      'contact': widget.snap.data['contact'],
      'bookedVendor': widget.snap['name'],
      'byUID': uid,
      'vendorUid': widget.snap.documentID,
      'bookedServices': servicesBooked,
      'logo': widget.snap['logo'],
      'logoBgColor': widget.snap['logoBgColor'],
      'status': 'Pending',
      'mobile': mobile.text,
      'address': address.text,
      'notificationToken': fcmToken,
    };
    Analytics().logBookingEvent(
        self: false,
        services: servicesBooked,
        vendorCategory: widget.snap.data['category'][0],
        vendorId: widget.snap.documentID,
        vendorName: widget.snap.data['name']);
    await ins.collection('bookings').add(data).catchError((onError) {
      setState(() {
        booking = false;
      });
      Fluttertoast.showToast(msg: "Error!, try again");
    });
    setState(() {
      booking = false;
    });
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (context) => DonePage(data: data),
        ),
        (route) => false);
  }

  bookForSelf() async {
    String fcmToken = await PushNotificationsManager().getToken();
    var time = DateTime.now().millisecondsSinceEpoch;
    List servicesBooked = [];
    widget.selectedServices.forEach((ele) {
      servicesBooked.add(widget.snap['services'][ele]);
    });
    Map<String, dynamic> data = {
      'by': nameController.text,
      'time': widget.selectedTime,
      'date':
          widget.selectedDate.toString().substring(0, 11) + widget.selectedTime,
      'timeStamp': time,
      'contact': widget.snap.data['contact'],
      'byUID': uid,
      'logo': widget.snap['logo'],
      'logoBgColor': widget.snap['logoBgColor'],
      'bookedVendor': widget.snap['name'],
      'vendorUid': widget.snap.documentID,
      'bookedServices': servicesBooked,
      'status': 'Pending',
      'mobile': phoneNumberController.text,
      'address': addressController.text,
      'notificationToken': fcmToken,
    };
    Analytics().logBookingEvent(
        self: true,
        services: servicesBooked,
        vendorCategory: widget.snap.data['category'][0],
        vendorId: widget.snap.documentID,
        vendorName: widget.snap.data['name']);
    await ins.collection('bookings').add(data).catchError((onError) {
      setState(() {
        bookforselfLoading = false;
      });
      Fluttertoast.showToast(msg: "Error!, try again");
    });
    setState(() {
      bookforselfLoading = false;
    });
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (context) => DashBoard(),
        ),
        (route) => true);
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (context) => DonePage(data: data),
        ),
        (route) => true);
  }
}
