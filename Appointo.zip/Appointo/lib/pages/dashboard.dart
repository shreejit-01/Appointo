import 'package:enterprise/widgets.dart/categorySlider.dart';
import 'package:enterprise/widgets.dart/imageSlider.dart';
import 'package:enterprise/widgets.dart/vendorCard.dart';
import 'package:flutter/material.dart';
import '../utils/constants.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geoflutterfire/geoflutterfire.dart';

class DashBoard extends StatefulWidget {
  DashBoard({Key key}) : super(key: key);

  @override
  _DashBoardState createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  GlobalKey<ScaffoldState> _scafKey = GlobalKey<ScaffoldState>();
  double radius = 50;

  // TextStyle welcome = GoogleFonts.headlandOne(fontSize: 30,color: white);
  TextStyle welcome = GoogleFonts.dmSans(fontSize: 44, color: white);
  @override
  void initState() {
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    if (popularList == null) getPopularList();
    getNearByList();
    getCategories();
    getImageSliderList();
    // updateGeoPointDataInDB();
    super.initState();
  }

  getPopularList() async {
    QuerySnapshot value = await ins
        .collection('vendors')
        .orderBy('rating', descending: true)
        .limit(4)
        .getDocuments();
    setState(() {
      popularList = value.documents;
    });
    if (popularList.length < 4) {
      ins
          .collection('vendors')
          .limit(4 - popularList.length)
          .getDocuments()
          .then((val) {
        setState(() {
          popularList.addAll(val.documents);
        });
      });
    }
  }

  updateGeoPointDataInDB() {
    ins.collection('vendors').getDocuments().then((value) {
      value.documents.forEach((element) {
        Geoflutterfire geo = Geoflutterfire();
        GeoFirePoint location = geo.point(
            latitude: element.data['location']['lat'],
            longitude: element.data['location']['long']);
        element.reference.updateData({'geoData': location.data});
      });
    });
  }

  getNearByList() async {
    Geoflutterfire geo = Geoflutterfire();
    QuerySnapshot value;
    if (position != null) {
      GeoFirePoint center =
          geo.point(latitude: position.latitude, longitude: position.longitude);
      Stream<List<DocumentSnapshot>> stream = geo
          .collection(collectionRef: ins.collection('vendors'))
          .within(center: center, radius: radius, field: 'geoData');
      stream.listen((event) {
        print(radius);
        if (event.length < 6) {
          setState(() {
            radius += 10;
          });
          getNearByList();
        } else
          setState(() {
            nearbyList = event.sublist(0, 5);
          });
      });
    } else {
      value = await ins
          .collection('vendors')
          // .orderBy('name')
          .limit(5)
          .getDocuments();
      setState(() {
        nearbyList = value.documents;
      });
    }
  }

  getImageSliderList() async {
    ins.collection('appData').document('imageSlider').get().then((value) {
      imageList = value.data['images'];
    });
  }

  getCategories() async {
    DocumentSnapshot categoriesSnap =
        await ins.collection('appData').document('categories').get();
    List categories = categoriesSnap.data['categories'];
    categoryList.clear();
    categoryIconList.clear();
    categories.forEach((element) {
      categoryList.add(element['category']);
      categoryIconList.add(element['icon']);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scafKey,
      appBar: AppBar(
        title: Image.asset('assets/brandLogo.png'),
        centerTitle: true,
      ),
      body: SafeArea(
          child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          children: [
            SizedBox(
              height: 5,
            ),
            imageList == null
                ? CircularProgressIndicator()
                : ImageSlider(
                    imageList: imageList,
                  ),
            SizedBox(
              height: 5,
            ),
            categories(),
            SizedBox(
              height: 10,
            ),
            popular(),
            SizedBox(
              height: 10,
            ),
            nearby(),
            SizedBox(
              height: 10,
            ),
          ],
        ),
      )),
    );
  }

  Widget categories() {
    return Container(
      child: Column(
        children: [
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 15),
                child: Text(
                  "Categories",
                  style: GoogleFonts.workSans(color: Colors.grey, fontSize: 23),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          categoryList.length == 0
              ? CircularProgressIndicator()
              : CategorySlider(
                  categoryList: categoryList,
                  categoryIconList: categoryIconList,
                )
        ],
      ),
    );
  }

  Widget popular() {
    return Container(
      child: Column(
        children: [
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 15),
                child: Text(
                  "Popular",
                  style: GoogleFonts.workSans(color: Colors.grey, fontSize: 23),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                SizedBox(
                  width: 10,
                ),
                Row(
                    children: popularList == null
                        ? [
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(50.0),
                                child: CircularProgressIndicator(),
                              ),
                            )
                          ]
                        : List.generate(
                            popularList.length,
                            (index) => Container(
                                  width:
                                      MediaQuery.of(context).size.width * .85,
                                  child: VendorCard(
                                    snap: popularList[index],
                                  ),
                                ))),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget nearby() {
    return Container(
      child: Column(
        children: [
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 15),
                child: Text(
                  "Nearby",
                  style: GoogleFonts.workSans(color: Colors.grey, fontSize: 23),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Column(
            children: nearbyList == null
                ? [
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.all(50.0),
                        child: CircularProgressIndicator(),
                      ),
                    )
                  ]
                : List.generate(
                    nearbyList.length,
                    (index) => Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: VendorCard(
                            snap: nearbyList[index],
                          ),
                        )),
          )
        ],
      ),
    );
  }
}
