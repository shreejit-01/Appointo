import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:carousel_slider/carousel_slider.dart';

class ReviewCard extends StatefulWidget {
  final DocumentSnapshot snap;
  ReviewCard({Key key, this.snap}) : super(key: key);

  @override
  _ReviewCardState createState() => _ReviewCardState();
}

class _ReviewCardState extends State<ReviewCard> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      child: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            color: Theme.of(context).cardColor,
            boxShadow: [BoxShadow(blurRadius: 2, color: Colors.grey)]),
        child: Column(
          children: [
            (widget.snap.data['photoUrl'] == null ||
                    widget.snap.data['photoUrl'].toString().isEmpty)
                ? Container()
                : Container(
                    width: MediaQuery.of(context).size.width - 16,
                    child: ClipRRect(
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(5)),
                      child: Image.network(
                        widget.snap.data['photoUrl'][0].toString(),
                        fit: BoxFit.fitWidth,
                        height: 80,
                      ),
                    ),
                  ),
            Stack(
              alignment: Alignment.topRight,
              children: [
                Padding(
                  padding: EdgeInsets.only(bottom: 7, left: 7, right: 7),
                  child: Row(
                    children: [
                      Container(
                        width: 75,
                        padding: EdgeInsets.all(5),
                        child: CircleAvatar(
                          backgroundColor: Colors.blue,
                          minRadius: 30,
                          maxRadius: 30,
                          backgroundImage:
                              (widget.snap.data['reviewerPhotoUrl'] == null ||
                                      widget.snap.data['reviewerPhotoUrl']
                                          .toString()
                                          .isEmpty)
                                  ? null
                                  : NetworkImage(widget
                                      .snap.data['reviewerPhotoUrl']
                                      .toString()),
                          child:
                              (widget.snap.data['reviewerPhotoUrl'] == null ||
                                      widget.snap.data['reviewerPhotoUrl']
                                          .toString()
                                          .isEmpty)
                                  ? Text(
                                      "A",
                                      style: TextStyle(
                                          fontSize: 30, color: Colors.white),
                                    )
                                  : null,
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width * .7,
                            padding: EdgeInsets.only(right: 20),
                            child: Wrap(
                              // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              direction: Axis.horizontal,
                              children: [
                                Text(
                                  widget.snap.data['reviewHeading'],
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                  style: GoogleFonts.workSans(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18),
                                ),
                                RatingBar(
                                  itemBuilder: (context, index) => Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                  ),
                                  glowColor: Colors.amber,
                                  ignoreGestures: true,
                                  itemCount: 5,
                                  minRating: 3,
                                  glow: true,
                                  unratedColor: Colors.grey,
                                  maxRating: 5,
                                  initialRating:
                                      double.parse(widget.snap.data['rating']),
                                  onRatingUpdate: (double value) {},
                                  itemSize: 17,
                                  itemPadding: EdgeInsets.only(right: 6),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width * .7,
                            child: Wrap(
                              children: [
                                Text(
                                  widget.snap.data['reviewBody'],
                                  style: GoogleFonts.workSans(
                                      color: Colors.grey,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 15),
                                ),
                              ],
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
                widget.snap.data['photoUrl'] == null ||
                        widget.snap.data['photoUrl'].length < 2
                    ? Container()
                    : Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text("+${widget.snap.data['photoUrl'].length - 1}"),
                          GestureDetector(
                              child: Icon(Icons.photo_camera),
                              onTap: () {
                                showReviewDetails(widget.snap.data['photoUrl']);
                              }),
                        ],
                      )
              ],
            )
          ],
        ),
      ),
    );
  }

  showReviewDetails(List images) {
    int _current = 0;
    CarouselController _carouselController = CarouselController();
    PageStorageKey<dynamic> _pageStorageKey;
    showDialog(
        context: context,
        barrierDismissible: false,
        barrierColor: Theme.of(context).accentColor.withOpacity(0.1),
        child: AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          contentPadding: EdgeInsets.all(8),
          content: Stack(
            alignment: Alignment.topRight,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 15.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      child: Stack(
                        alignment: Alignment.bottomCenter,
                        children: [
                          CarouselSlider(
                            options: CarouselOptions(
                              carouselController: _carouselController,
                              // height: MediaQuery.of(context).size.height * 0.3,
                              initialPage: 0,
                              pageViewKey: _pageStorageKey,
                              onPageChanged: (index, reason) {
                                setState(() {
                                  _current = index;
                                });
                              },
                            ),
                            items: List.generate(
                                images.length,
                                (index) => Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width,
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(4),
                                          child: Image.network(
                                            images[index],
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                    )),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: images.map((url) {
                              int index = images.indexOf(url);
                              return Container(
                                width: 8.0,
                                height: 8.0,
                                margin: EdgeInsets.symmetric(
                                    vertical: 15.0, horizontal: 4.0),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.grey),
                                  color: _current == index
                                      ? Colors.grey
                                      : Colors.transparent,
                                ),
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              width: 75,
                              padding: EdgeInsets.all(5),
                              child: CircleAvatar(
                                backgroundColor: Colors.blue,
                                minRadius: 30,
                                maxRadius: 30,
                                backgroundImage:
                                    (widget.snap.data['reviewerPhotoUrl'] ==
                                                null ||
                                            widget.snap.data['reviewerPhotoUrl']
                                                .toString()
                                                .isEmpty)
                                        ? null
                                        : NetworkImage(widget
                                            .snap.data['reviewerPhotoUrl']
                                            .toString()),
                                child: (widget.snap.data['reviewerPhotoUrl'] ==
                                            null ||
                                        widget.snap.data['reviewerPhotoUrl']
                                            .toString()
                                            .isEmpty)
                                    ? Text(
                                        "A",
                                        style: TextStyle(
                                            fontSize: 30, color: Colors.white),
                                      )
                                    : null,
                              ),
                            ),
                            Text(widget.snap.data['reviewerName'])
                          ],
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * .7,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RatingBar(
                                itemBuilder: (context, index) => Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                ),
                                glowColor: Colors.amber,
                                ignoreGestures: true,
                                itemCount: 5,
                                minRating: 3,
                                glow: true,
                                unratedColor: Colors.grey,
                                maxRating: 5,
                                initialRating:
                                    double.parse(widget.snap.data['rating']),
                                onRatingUpdate: (double value) {},
                                itemSize: 17,
                                itemPadding: EdgeInsets.only(right: 6),
                              ),
                              Text(
                                widget.snap.data['reviewHeading'],
                                overflow: TextOverflow.clip,
                                maxLines: 1,
                                style: GoogleFonts.workSans(
                                    fontWeight: FontWeight.w400, fontSize: 18),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * .7,
                          child: Wrap(
                            children: [
                              Text(
                                widget.snap.data['reviewBody'],
                                style: GoogleFonts.workSans(
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 15),
                              ),
                            ],
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
              IconButton(
                  icon: Icon(Icons.clear),
                  padding: EdgeInsets.all(0),
                  color: Theme.of(context).accentColor,
                  alignment: Alignment.topRight,
                  onPressed: () => Navigator.pop(context))
            ],
          ),
        ));
  }
}
