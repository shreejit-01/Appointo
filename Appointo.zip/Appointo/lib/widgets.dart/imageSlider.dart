import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class ImageSlider extends StatefulWidget {
  final List imageList;
  ImageSlider({Key key, this.imageList}) : super(key: key);

  @override
  _ImageSliderState createState() => _ImageSliderState();
}

class _ImageSliderState extends State<ImageSlider> {
  CarouselController _carouselController = CarouselController();
  PageStorageKey<dynamic> _pageStorageKey;
  int _current = 0;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          CarouselSlider(
            options: CarouselOptions(
              carouselController: _carouselController,
              height: 170,
              initialPage: 0,
              autoPlay: true,
              pageViewKey: _pageStorageKey,
              onPageChanged: (index, reason) {
                setState(() {
                  _current = index;
                });
              },
            ),
            items: List.generate(
                widget.imageList.length,
                (index) => Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: Image.network(
                            widget.imageList[index],
                            fit: BoxFit.fill,
                          ),
                        ),
                      ),
                    )),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: widget.imageList.map((url) {
              int index = widget.imageList.indexOf(url);
              return Container(
                width: 8.0,
                height: 8.0,
                margin: EdgeInsets.symmetric(vertical: 15.0, horizontal: 4.0),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.grey),
                  color: _current == index ? Colors.grey : Colors.transparent,
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
