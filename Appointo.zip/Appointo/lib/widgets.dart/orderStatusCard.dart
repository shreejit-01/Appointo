import 'dart:ui';
import 'dart:io';
import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:jiffy/jiffy.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:multi_image_picker/multi_image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

//Cards shows for order status

//might be difficult to understand since both history and orders page share same widget
class OrderStatusCard extends StatefulWidget {
  final bool history;
  final bool popup;
  final DocumentSnapshot snap;
  OrderStatusCard({Key key, this.snap, this.history, this.popup})
      : super(key: key);

  @override
  _OrderStatusCardState createState() => _OrderStatusCardState();
}

class _OrderStatusCardState extends State<OrderStatusCard> {
  double ratingValue = 0;
  TextEditingController reviewHeading = TextEditingController(),
      reviewBody = TextEditingController();
  bool reviewSubmited = false;
  List<Asset> imageAssetList = [];
  @override
  void initState() {
    if (widget.snap.data['rating'] != null)
      ratingValue = double.parse(widget.snap.data['rating'].toString());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: GestureDetector(
        //Popup shown after taping the order status card
        onTap: () {
          //Popup shows  only if status is not 'canceled' and widget.popup varibale is false

          if (widget.snap.data['status'].toString().toLowerCase() ==
                  'canceled' ||
              widget.popup) {
          } else
            showDialog(
                context: context,
                barrierDismissible: false,
                useSafeArea: true,
                builder: (context) => Scaffold(
                      backgroundColor: Colors.transparent,
                      body: ChangeNotifierProvider<ReviewImageLoaded>(
                        create: (context) => ReviewImageLoaded(),
                        builder: (context, child) => child,
                        child: Consumer<ReviewImageLoaded>(
                          builder: (context, value, child) => Center(
                            child: Container(
                              decoration: BoxDecoration(
                                color: Theme.of(context).cardColor,
                                boxShadow: [
                                  BoxShadow(blurRadius: 2, color: Colors.grey),
                                ],
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    OrderStatusCard(
                                      snap: widget.snap,
                                      history: false,
                                      popup: true,
                                    ),

                                    //Shows 'Rejected due to unavailability of slot' text if the Status is pending and the order time is expired
                                    (widget.snap['status']
                                                    .toString()
                                                    .toLowerCase() ==
                                                'pending' &&
                                            (DateTime.now().compareTo(
                                                    DateTime.parse(
                                                        widget.snap['date'])) >
                                                0)
                                        ? Padding(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 5),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                Container(
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.8,
                                                  child: Text(
                                                    "Rejected due to unavailability of slot",
                                                    textAlign: TextAlign.end,
                                                    style:
                                                        TextStyle(fontSize: 12),
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 5,
                                                ),
                                                (!widget.history)
                                                    ? GestureDetector(
                                                        onTap: () {
                                                          launch('tel:' +
                                                              widget.snap.data[
                                                                  'contact']);
                                                        },
                                                        child: FaIcon(
                                                          FontAwesomeIcons
                                                              .phoneAlt,
                                                          color: Colors.green,
                                                        ),
                                                      )
                                                    : Container(),
                                                SizedBox(
                                                  width: 5,
                                                )
                                              ],
                                            ),
                                          )
                                        : widget.snap['status']
                                                    .toString()
                                                    .toLowerCase() ==
                                                'rejected'
                                            ? Container(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.9,
                                                child: Padding(
                                                  padding: const EdgeInsets
                                                      .symmetric(vertical: 5),
                                                  child: Text(
                                                    widget.snap.data[
                                                            'rejectedReason'] ??
                                                        "",
                                                    textAlign: TextAlign.start,
                                                    style:
                                                        TextStyle(fontSize: 12),
                                                  ),
                                                ),
                                              )
                                            : Container()),

                                    //Review options shows only if it is not given previously (rating value is not set in the db(in the  bookings document) )
                                    widget.snap.data['rating'] == null &&
                                            widget.snap['status']
                                                    .toString()
                                                    .toLowerCase() !=
                                                'rejected' &&
                                            !widget.history
                                        ? Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                RatingBar(
                                                  itemBuilder:
                                                      (context, index) => Icon(
                                                    Icons.star,
                                                    color: Colors.amber,
                                                  ),
                                                  glowColor: Colors.amber,
                                                  itemCount: 5,
                                                  minRating: 1,
                                                  glow: true,
                                                  unratedColor:
                                                      Theme.of(context)
                                                          .accentColor,
                                                  maxRating: 5,
                                                  initialRating: ratingValue,
                                                  onRatingUpdate:
                                                      (double value) {
                                                    setState(() {
                                                      ratingValue = value;
                                                    });
                                                  },
                                                  itemSize: 25,
                                                  itemPadding:
                                                      EdgeInsets.symmetric(
                                                          horizontal:
                                                              MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .width *
                                                                  0.02),
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                imageSlider(value),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                TextFormField(
                                                  controller: reviewHeading,
                                                  decoration: InputDecoration(
                                                      hintText: "Title / Snap",
                                                      hintStyle: TextStyle(
                                                          color: Theme.of(context)
                                                              .accentColor
                                                              .withOpacity(
                                                                  0.6)),
                                                      border: OutlineInputBorder(
                                                          borderSide: BorderSide(
                                                              color: Theme.of(context)
                                                                  .accentColor)),
                                                      enabled: true,
                                                      enabledBorder: OutlineInputBorder(
                                                          borderSide: BorderSide(
                                                              color: Theme.of(context)
                                                                  .accentColor)),
                                                      focusedBorder: OutlineInputBorder(
                                                          borderSide:
                                                              BorderSide(color: Theme.of(context).accentColor))),
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                TextFormField(
                                                  controller: reviewBody,
                                                  maxLines: 2,
                                                  decoration: InputDecoration(
                                                      hintText:
                                                          "write your review",
                                                      hintStyle: TextStyle(
                                                          color: Theme.of(context)
                                                              .accentColor
                                                              .withOpacity(
                                                                  0.6)),
                                                      border: OutlineInputBorder(
                                                          borderSide: BorderSide(
                                                              color: Theme.of(context)
                                                                  .accentColor)),
                                                      enabled: true,
                                                      enabledBorder: OutlineInputBorder(
                                                          borderSide: BorderSide(
                                                              color: Theme.of(context)
                                                                  .accentColor)),
                                                      focusedBorder: OutlineInputBorder(
                                                          borderSide:
                                                              BorderSide(color: Theme.of(context).accentColor))),
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: [
                                                    RaisedButton(
                                                      onPressed: () {
                                                        Navigator.pop(context);
                                                      },
                                                      child: Text(
                                                        "cancel",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    RaisedButton(
                                                      onPressed: () async {
                                                        if (reviewBody
                                                                .text.isNotEmpty &&
                                                            reviewHeading.text
                                                                .isNotEmpty &&
                                                            ratingValue != 0) {
                                                          reviewSubmited = true;
                                                          ins
                                                              .collection(
                                                                  'bookings')
                                                              .document(widget
                                                                  .snap
                                                                  .documentID)
                                                              .updateData({
                                                            'rating':
                                                                ratingValue
                                                                    .toString()
                                                          });
                                                          showProgressPopup(
                                                              context);
                                                          List<String> urls;
                                                          if (value.imageAssets
                                                                  .length !=
                                                              0)
                                                            urls = await uploadPhoto(
                                                                value
                                                                    .imageAssets);
                                                          await ins
                                                              .collection(
                                                                  'reviews')
                                                              .add({
                                                            'rating':
                                                                ratingValue
                                                                    .toString(),
                                                            'reviewHeading':
                                                                reviewHeading
                                                                    .text,
                                                            'reviewBody':
                                                                reviewBody.text,
                                                            'reviewerUid': uid,
                                                            'reviewerPhotoUrl':
                                                                photoURL,
                                                            'reviewerName':
                                                                nameController
                                                                    .text,
                                                            'uid': widget
                                                                    .snap.data[
                                                                'vendorUid'],
                                                            'photoUrl': urls
                                                          });
                                                          Fluttertoast.showToast(
                                                              msg:
                                                                  "Thank you for your review");
                                                          bottomNavIndex = 1;
                                                          Navigator
                                                              .pushNamedAndRemoveUntil(
                                                                  context,
                                                                  'home',
                                                                  (route) =>
                                                                      false);
                                                        } else {
                                                          Fluttertoast.showToast(
                                                              msg:
                                                                  "Incomplete review");
                                                        }
                                                      },
                                                      child: Text(
                                                        "Submit",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          )
                                        : Container(
                                            child: RaisedButton(
                                              onPressed: () {
                                                Navigator.pop(context);
                                              },
                                              child: Text(
                                                "OK",
                                                style: TextStyle(
                                                    color: Colors.white),
                                              ),
                                            ),
                                          )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ));
        },
        child: Container(
          decoration: BoxDecoration(
            backgroundBlendMode: BlendMode.color,
            gradient: LinearGradient(colors: [
              Theme.of(context).cardColor,
              Theme.of(context).cardColor
            ]),
            color: widget.snap.data['logoBgColor'] == null
                ? widget.snap.data['status'].toString().toLowerCase() ==
                        'canceled'
                    ? Colors.blue.withOpacity(0.5)
                    : Colors.blue
                : widget.snap.data['status'].toString().toLowerCase() ==
                        'canceled'
                    ? Color(
                        int.parse(
                          widget.snap['logoBgColor'],
                        ),
                      ).withOpacity(0.5)
                    : Color(
                        int.parse(
                          widget.snap['logoBgColor'],
                        ),
                      ),
            boxShadow: [
              BoxShadow(blurRadius: 2, color: Colors.grey),
            ],
            borderRadius: BorderRadius.circular(8),
          ),
          child: Column(
            children: [
              Container(
                height: 140,
                decoration: BoxDecoration(
                  backgroundBlendMode: BlendMode.src,
                  color: Theme.of(context).cardColor,
                  gradient: SweepGradient(
                      colors: [
                        widget.snap.data['status'].toString().toLowerCase() ==
                                'canceled'
                            ? Theme.of(context).cardColor.withOpacity(0.5)
                            : Theme.of(context).cardColor,
                        widget.snap.data['logoBgColor'] == null
                            ? widget.snap.data['status']
                                        .toString()
                                        .toLowerCase() ==
                                    'canceled'
                                ? Colors.blue.withOpacity(0.5)
                                : Colors.blue
                            : widget.snap.data['status']
                                        .toString()
                                        .toLowerCase() ==
                                    'canceled'
                                ? Color(
                                    int.parse(
                                      widget.snap['logoBgColor'],
                                    ),
                                  ).withOpacity(0.5)
                                : Color(
                                    int.parse(
                                      widget.snap['logoBgColor'],
                                    ),
                                  ),
                      ],
                      endAngle: 3.141,
                      startAngle: 1.571,
                      center: Alignment.centerLeft,
                      tileMode: TileMode.clamp),
                  // boxShadow: [
                  //   BoxShadow(blurRadius: 3, color: Colors.grey),
                  // ],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 5,
                    ),
                    (widget.snap == null || widget.snap.data['logo'] == null)
                        ? Icon(
                            Icons.card_travel,
                            size: 80,
                          )
                        : CircleAvatar(
                            radius: 65,
                            backgroundColor: widget.snap['logoBgColor'] == null
                                ? Colors.blue
                                : Color(int.parse(widget.snap['logoBgColor'])),
                            backgroundImage:
                                NetworkImage(widget.snap.data['logo']),
                          ),
                    SizedBox(
                      width: 5,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.55,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Stack(
                              children: [
                                Container(
                                  alignment: Alignment.bottomLeft,
                                  child: Text(
                                    widget.snap['bookedVendor'],
                                    style: GoogleFonts.openSans(
                                        fontSize: 20,
                                        color: widget.snap.data['status']
                                                    .toString()
                                                    .toLowerCase() ==
                                                'canceled'
                                            ? white.withOpacity(0.5)
                                            : white),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    // textAlign: TextAlign.left,
                                  ),
                                ),
                                widget.snap.data['status']
                                                .toString()
                                                .toLowerCase() ==
                                            'canceled' ||
                                        (!widget.history && widget.popup)
                                    ? Container()
                                    : Align(
                                        alignment: Alignment.topRight,
                                        child: IconButton(
                                            icon: Icon(Icons.remove_red_eye),
                                            onPressed: null),
                                      )
                              ],
                            ),
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          'Status:',
                                          style: GoogleFonts.jacquesFrancois(
                                              color: widget.snap.data['status']
                                                          .toString()
                                                          .toLowerCase() ==
                                                      'canceled'
                                                  ? Theme.of(context)
                                                      .accentColor
                                                      .withOpacity(0.5)
                                                  : Theme.of(context)
                                                      .accentColor),
                                        ),
                                        Text(
                                            (widget.snap['status']
                                                            .toString()
                                                            .toLowerCase() ==
                                                        'pending' &&
                                                    widget.history)
                                                ? 'REJECTED'
                                                : (widget.snap['status']
                                                            .toString()
                                                            .toLowerCase() ==
                                                        'canceled')
                                                    ? "CANCELED"
                                                    : (DateTime.now().compareTo(DateTime.parse(widget.snap['date'])) > 0)
                                                        ? "REJECTED"
                                                        : widget.snap['status']
                                                            .toString()
                                                            .toUpperCase(),
                                            style: GoogleFonts.jacquesFrancois(
                                                color: widget.snap['status']
                                                            .toString()
                                                            .toLowerCase() ==
                                                        'booked'
                                                    ? Colors.green
                                                    : Theme.of(context)
                                                        .accentColor
                                                        .withOpacity(0.6))),
                                      ],
                                    ),
                                  ],
                                ),
                                Text(
                                  'Date: ${Jiffy(DateTime.parse(widget.snap['date'])).format('do MMMM yyyy')}',
                                  style: GoogleFonts.jacquesFrancois(
                                      color: widget.snap.data['status']
                                                  .toString()
                                                  .toLowerCase() ==
                                              'canceled'
                                          ? Theme.of(context)
                                              .accentColor
                                              .withOpacity(0.5)
                                          : Theme.of(context).accentColor),
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      'Time: ${widget.snap['time']}',
                                      style: GoogleFonts.jacquesFrancois(
                                          color: widget.snap.data['status']
                                                      .toString()
                                                      .toLowerCase() ==
                                                  'canceled'
                                              ? Theme.of(context)
                                                  .accentColor
                                                  .withOpacity(0.5)
                                              : Theme.of(context).accentColor),
                                    ),
                                    (widget.history == false && widget.popup) ||
                                            (DateTime.now().compareTo(
                                                    DateTime.parse(
                                                        widget.snap['date'])) >
                                                0) ||
                                            widget.snap.data['status']
                                                    .toString()
                                                    .toLowerCase() ==
                                                'rejected' ||
                                            widget.snap.data['status']
                                                    .toString()
                                                    .toLowerCase() ==
                                                'canceled'
                                        ? Container()
                                        : GestureDetector(
                                            onTap: () {
                                              showDialog(
                                                  context: context,
                                                  child: AlertDialog(
                                                    title:
                                                        Text("Cancel order?"),
                                                    content: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        RaisedButton(
                                                          onPressed: () async {
                                                            // Firestore.instance
                                                            //     .collection(
                                                            //         'canceledBooking')
                                                            //     .document(widget
                                                            //         .snap
                                                            //         .documentID)
                                                            //     .setData(widget
                                                            //         .snap.data);

                                                            Firestore.instance
                                                                .collection(
                                                                    'bookings')
                                                                .document(widget
                                                                    .snap
                                                                    .documentID)
                                                                .updateData({
                                                              'status':
                                                                  "canceled"
                                                            });
                                                            bottomNavIndex = 1;
                                                            Navigator
                                                                .pushNamedAndRemoveUntil(
                                                                    context,
                                                                    'home',
                                                                    (route) =>
                                                                        false);
                                                          },
                                                          child: Text("Yes",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .white)),
                                                        ),
                                                        RaisedButton(
                                                          onPressed: () {
                                                            Navigator.pop(
                                                                context);
                                                          },
                                                          child: Text("No",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .white)),
                                                        ),
                                                      ],
                                                    ),
                                                  ));
                                            },
                                            child: Text("cancel?",
                                                style:
                                                    GoogleFonts.jacquesFrancois(
                                                        decoration:
                                                            TextDecoration
                                                                .underline,
                                                        color: Theme.of(context)
                                                            .accentColor
                                                            .withOpacity(0.6))),
                                          )
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  imageSlider(ReviewImageLoaded val) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(
                  val.imageAssets.length,
                  (index) => Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 5),
                        child: Stack(
                          alignment: Alignment.topRight,
                          children: [
                            Container(
                              height: 70,
                              width: 70,
                              child: AssetThumb(
                                asset: val.imageAssets[index],
                                height: 70,
                                width: 70,
                              ),
                            ),
                            IconButton(
                                icon: Icon(Icons.clear),
                                padding: EdgeInsets.all(0),
                                alignment: Alignment.topRight,
                                iconSize: 18,
                                onPressed: () {
                                  val.removeAssetAtIndex(index);
                                })
                          ],
                        ),
                      ))),
          IconButton(
            icon: Icon(Icons.add_a_photo),
            iconSize: 30,
            onPressed: () {
              imagePick(val);
            },
          ),
        ],
      ),
    );
  }

  imagePick(ReviewImageLoaded val) async {
    List<Asset> images = [];
    var resultList = await MultiImagePicker.pickImages(
      maxImages: 5,
      enableCamera: true,
      selectedAssets: images,
    );
    val.updateValue(resultList);
    setState(() {
      imageAssetList = resultList;
    });
  }

  uploadPhoto(List<Asset> file) async {
    List<String> urlList = [];
    StorageReference ref = FirebaseStorage.instance.ref();
    Directory dir = await getTemporaryDirectory();
    for (var i = 0; i < file.length; i++) {
      StorageReference fileRef = ref.child(
          "vendor_data/${widget.snap.data['vendorUid']}/review_photos/${widget.snap.documentID}/$i");
      StorageTaskSnapshot task = await fileRef
          .putData((await file[i].getByteData()).buffer.asUint8List())
          .onComplete;
      var url = await task.ref.getDownloadURL();
      urlList.add(url.toString());
    }
    return urlList;
  }

  showProgressPopup(BuildContext context) {
    showDialog(
        context: context,
        barrierDismissible: false,
        child: AlertDialog(
          backgroundColor: Colors.transparent,
          contentPadding: EdgeInsets.all(0),
          content: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Theme.of(context).cardColor,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: CircularProgressIndicator(),
                ),
              ),
            ],
          ),
        ));
  }
}

class ReviewImageLoaded extends ChangeNotifier {
  List<Asset> imageAssets = [];
  updateValue(List<Asset> val) {
    imageAssets = val;
    notifyListeners();
  }

  removeAssetAtIndex(int index) {
    imageAssets.removeAt(index);
    notifyListeners();
  }
}
