import 'dart:ui';
import 'package:enterprise/pages/vendorSelectedPage.dart';
import 'package:enterprise/services/analytics.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_fonts/google_fonts.dart';

class VendorCard extends StatefulWidget {
  final DocumentSnapshot snap;
  final Color variant;
  VendorCard({Key key, this.snap, this.variant}) : super(key: key);

  @override
  _VendorCardState createState() => _VendorCardState();
}

class _VendorCardState extends State<VendorCard> {
  Color variant = Colors.blue;

  // @override
  // void initState() {
  //   setCardColor();
  //   super.initState();
  // }

  // setCardColor() async {
  //   Color dominantColor =
  //       await getImagePalette(NetworkImage(widget.snap.data['logo']));
  //   var bgcolor = CalculateComplimentaryColor.fromHex(
  //       col.HexColor(dominantColor.value.toRadixString(16)));
  //   setState(() {
  //     variant = Color.fromRGBO(bgcolor.r, bgcolor.g, bgcolor.b, 1);
  //   });
  //   print(variant);
  // }

  // Future<Color> getImagePalette(ImageProvider imageProvider) async {
  //   final PaletteGenerator paletteGenerator =
  //       await PaletteGenerator.fromImageProvider(
  //     imageProvider,
  //     size: Size(1, 1),
  //     maximumColorCount: 1,
  //   );
  //   return paletteGenerator.dominantColor.titleTextColor;
  // }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      child: GestureDetector(
        onTap: () {
          Analytics().logVendorView(
              vendorCategory: widget.snap.data['category'][0],
              vendorName: widget.snap.data['name'],
              vendorId: widget.snap.documentID);
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => VendorDetails(
                  snap: widget.snap,
                ),
              ));
        },
        child: Container(
          height: 110,
          decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              gradient: SweepGradient(
                  colors: [
                    Theme.of(context).cardColor,
                    widget.snap['logoBgColor'] == null
                        ? variant
                        : Color(int.parse(widget.snap['logoBgColor']))
                  ],
                  endAngle: 3.141,
                  startAngle: 1.571,
                  center: Alignment.centerLeft,
                  tileMode: TileMode.clamp),
              boxShadow: [
                BoxShadow(blurRadius: 3, color: Colors.grey),
              ],
              borderRadius: BorderRadius.circular(8)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              (widget.snap.data['logo'] == null)
                  ? Icon(
                      Icons.card_travel,
                      size: 80,
                    )
                  : Container(
                      height: 100,
                      width: 100,
                      child: CircleAvatar(
                        radius: 50,
                        backgroundImage: NetworkImage(
                          widget.snap.data['logo'],
                        ),
                      ),
                    ),
              Container(
                width: MediaQuery.of(context).size.width * 0.48,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      flex: 1,
                      child: Container(
                        alignment: Alignment.bottomLeft,
                        child: Text(
                          widget.snap.data['name'],
                          style:
                              GoogleFonts.openSans(fontSize: 20, color: white),
                          overflow: TextOverflow.clip,
                          maxLines: 1,
                          // textAlign: TextAlign.left,
                        ),
                      ),
                    ),
                    // SizedBox(
                    //   height: 5,
                    // ),
                    Expanded(
                      flex: 1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.snap.data['category'][0],
                            style: GoogleFonts.jacquesFrancois(),
                          ),
                          widget.snap['rating'] == null
                              ? Container()
                              : Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    RatingBar(
                                      itemBuilder: (context, index) => Icon(
                                        Icons.star,
                                        color: Colors.amber,
                                      ),
                                      glowColor: Colors.amber,
                                      ignoreGestures: true,
                                      itemCount: 5,
                                      minRating: 3,
                                      glow: true,
                                      unratedColor: Colors.grey,
                                      maxRating: 5,
                                      initialRating:
                                          double.parse(widget.snap['rating']),
                                      onRatingUpdate: (double value) {},
                                      itemSize: 17,
                                      itemPadding: EdgeInsets.only(right: 6),
                                    ),
                                  ],
                                ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
