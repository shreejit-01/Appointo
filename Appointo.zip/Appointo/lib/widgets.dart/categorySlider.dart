import 'package:enterprise/pages/search.dart';
import 'package:enterprise/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CategorySlider extends StatefulWidget {
  final List<dynamic> categoryList, categoryIconList;
  CategorySlider({Key key, this.categoryList, this.categoryIconList})
      : super(key: key);

  @override
  _CategorySliderState createState() => _CategorySliderState();
}

class _CategorySliderState extends State<CategorySlider> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          SizedBox(
            width: 15,
          ),
          Row(
            children: List.generate(
                widget.categoryList.length,
                (index) => Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 5),
                      child: GestureDetector(
                        onTap: () {
                          bottomNavIndex = 2;
                          Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                builder: (context) => SearchPage(
                                  filterCategory: [categoryList[index]],
                                ),
                              ),
                              (route) => false);
                        },
                        child: Container(
                          // width: 150,
                          decoration: BoxDecoration(
                              color: Theme.of(context).cardColor,
                              borderRadius: BorderRadius.circular(5),
                              boxShadow: [
                                BoxShadow(
                                  color: Theme.of(context).canvasColor,
                                  blurRadius: 1,
                                ),
                              ]),
                          padding: EdgeInsets.all(4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(3.0),
                                child: (widget.categoryIconList == null ||
                                        widget.categoryIconList.length <= index)
                                    ? Icon(Icons.card_giftcard,
                                        size: 45,
                                        color: Colors.black.withOpacity(0.5))
                                    : Container(
                                        height: 45,
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(5),
                                          child: Image.network(
                                              widget.categoryIconList[index]),
                                        )),
                              ),
                              Container(
                                width: 80,
                                child: Text(
                                  widget.categoryList[index].toString(),
                                  textAlign: TextAlign.left,
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 3,
                                  style: GoogleFonts.workSans(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 11),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    )),
          ),
        ],
      ),
    );
  }
}
